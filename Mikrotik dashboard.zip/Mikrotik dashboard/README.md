# MikroTik RouterOS Management Dashboard

A production-ready, modern web-based dashboard for managing and monitoring MikroTik RouterOS devices with comprehensive network automation capabilities.

## 📋 Features

### 🔧 Core Features
- **Multi-Router Management**: Add, edit, delete, and monitor multiple MikroTik devices
- **Real-time Monitoring**: Live CPU, RAM, uptime, and traffic statistics
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Dark Mode**: Beautiful light and dark theme support
- **Role-Based Access Control**: Super Admin, Network Admin, Operator, and Viewer roles

### 🌐 Network Features
#### Router Management
- Router add/edit/delete with API credentials
- Connection status monitoring (online/offline/error)
- System identity and version tracking
- Automatic sync and health checks

#### Interface Management
- List all interfaces with real-time traffic stats
- Enable/disable interfaces via API
- Traffic RX/TX monitoring
- Interface statistics history
- IP address management
- DHCP server and lease monitoring

#### Firewall Management
- View/create/delete firewall filter rules
- NAT rule management
- Mangle rule management
- Chain organization (input, output, forward, srcnat, dstnat)

#### Queue Management
- Simple Queue creation and monitoring
- Queue Tree management
- Bandwidth allocation and monitoring
- Traffic shaping rules

#### VPN Management
- PPP active sessions monitoring
- PPP secrets management (encrypted storage)
- L2TP, PPTP, OpenVPN support
- Session uptime and traffic tracking

#### Wireless Management
- Wireless interface monitoring
- Connected client list with signal strength
- SSID and security profile management
- Client bandwidth usage

#### Other Features
- Static route management
- System resource monitoring
- Activity logging
- Audit trail with detailed tracking
- DHCP lease management

## 🏗️ Project Structure

```
mikrotik-dashboard/
├── app/
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── RouterController.php
│   │   │   ├── InterfaceController.php
│   │   │   ├── FirewallController.php
│   │   │   ├── QueueController.php
│   │   │   └── UserController.php
│   │   └── Requests/
│   │       └── RouterRequest.php
│   ├── Models/
│   │   ├── User.php
│   │   ├── Router.php
│   │   ├── Interface.php
│   │   ├── NetworkModels.php
│   │   ├── FirewallQueueModels.php
│   │   └── VpnWirelessModels.php
│   └── Services/
│       ├── MikroTikService.php
│       └── RouterSyncService.php
├── database/
│   ├── migrations/
│   └── seeders/
├── resources/
│   ├── css/
│   │   └── app.css
│   └── views/
│       ├── layouts/
│       │   ├── app.blade.php
│       │   ├── sidebar.blade.php
│       │   ├── topbar.blade.php
│       │   └── breadcrumb.blade.php
│       ├── dashboard.blade.php
│       ├── routers/
│       └── users/
├── routes/
│   └── web.php
├── config/
│   └── app.php
├── composer.json
├── .env.example
└── README.md
```

## 🚀 Installation & Setup

### Prerequisites
- PHP 8.2 or higher
- MySQL/MariaDB 5.7+
- Composer
- Node.js 16+ (for Tailwind CSS compilation)
- Redis (optional, for queue processing)

### Step 1: Clone & Install Dependencies

```bash
# Clone or extract the project
cd mikrotik-dashboard

# Install PHP dependencies
composer install

# Install JavaScript dependencies
npm install

# Create .env file
cp .env.example .env

# Generate application key
php artisan key:generate
```

### Step 2: Database Configuration

Edit `.env` file with your database credentials:

```env
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=mikrotik_dashboard
DB_USERNAME=root
DB_PASSWORD=
```

### Step 3: Database Migration & Seeding

```bash
# Run migrations
php artisan migrate

# Seed default roles and permissions
php artisan db:seed

# This creates default admin user:
# Email: admin@mikrotik.local
# Password: Password@123
```

### Step 4: Build Frontend Assets

```bash
# Development
npm run dev

# Production
npm run build
```

### Step 5: Configure MikroTik API

On your MikroTik RouterOS device:

1. **Enable API Service**
   ```
   [/ip/service/enable api]
   ```

2. **Create API User**
   ```
   [/user/add name=dashboard password=YourPassword group=full]
   ```

3. **Set Permissions** (if using limited user)
   - IP → Services → API
   - System → API
   - Interface & Routing (depends on what you want to monitor)

### Step 6: Start Application

```bash
# Development server
php artisan serve

# Access at: http://localhost:8000
```

## 🔐 FirstTime Setup

1. **Login**
   - Email: `admin@mikrotik.local`
   - Password: `Password@123`

2. **Change Default Password**
   - Go to profile settings and change password immediately

3. **Add First Router**
   - Dashboard → Add Router
   - Enter MikroTik router IP, API port (8728), username, and password
   - Click "Add Router"
   - Dashboard will automatically test connection and sync data

4. **Create Additional Users**
   - Administration → Users
   - Click "Create User"
   - Assign appropriate roles

## 📊 Database Schema Overview

### Core Tables
- `users` - User accounts with soft deletes
- `roles` - User roles (super_admin, network_admin, operator, viewer)
- `permissions` - Granular permissions
- `role_user` - Role assignments
- `role_permission` - Permission mapping

### Router Tables
- `routers` - Router configurations
- `router_credentials` - Encrypted API credentials
- `interfaces` - Network interfaces
- `interface_stats` - Historical interface statistics
- `ip_addresses` - IP address configurations
- `dhcp_servers` - DHCP server configs
- `dhcp_leases` - DHCP client leases

### Firewall Tables
- `firewall_filters` - Filter rules
- `firewall_nats` - NAT rules
- `firewall_mangles` - Mangle rules

### Queue Tables
- `simple_queues` - Simple queues
- `queue_trees` - Queue tree structures

### VPN & Wireless
- `ppp_secrets` - VPN user accounts (encrypted)
- `ppp_sessions` - Active VPN sessions
- `wireless_interfaces` - WiFi configs
- `wireless_clients` - Connected WiFi clients

### Monitoring Tables
- `system_stats` - CPU, RAM, uptime history
- `activity_logs` - User activity tracking
- `audit_logs` - Security and change logs

## 🔑 API Integration Details

### MikroTik API Service

The `MikroTikService` class provides a complete API wrapper:

```php
$service = new MikroTikService($router);

// Connect
$service->connect();

// Get system info
$info = $service->getSystemInfo();

// Get interfaces
$interfaces = $service->getInterfaces();

// Get interface stats
$stats = $service->getInterfaceStats('ether1');

// Execute custom command
$result = $service->query('/ip/address');

// Disconnect
$service->disconnect();
```

### Supported API Endpoints

**System**
- `/system/identity` - Get router identity
- `/system/package` - Get RouterOS version
- `/system/resource` - Get CPU/RAM stats
- `/system/license` - Get license info

**Interfaces**
- `/interface` - List interfaces
- `/interface/wireless` - WiFi interfaces
- `/interface/wireless/registration-table` - Connected WiFi clients

**IP**
- `/ip/address` - IP address management
- `/ip/dhcp-server` - DHCP servers
- `/ip/dhcp-server/lease` - DHCP leases
- `/ip/firewall/filter` - Filter rules
- `/ip/firewall/nat` - NAT rules
- `/ip/firewall/mangle` - Mangle rules

**Queues**
- `/queue/simple` - Simple queues
- `/queue/tree` - Queue trees

**PPP**
- `/ppp/secret` - VPN user accounts
- `/ppp/active` - Active PPP sessions

## 🔒 Security Features

1. **Password Hashing**: All passwords hashed with bcrypt
2. **Credential Encryption**: Router API credentials encrypted with AES-256
3. **CSRF Protection**: All forms protected with CSRF tokens
4. **Rate Limiting**: API endpoints rate-limited by default
5. **Audit Logging**: All actions logged with user and IP tracking
6. **Role-Based Access**: Granular permission control
7. **Session Management**: Automatic logout on inactivity

## 📱 Responsive Design

- **Mobile**: Optimized for 320px and above
- **Tablet**: Optimized layout for 768px devices
- **Desktop**: Full-featured experience at 1024px+
- **Dark Mode**: Automatic or manual toggle

## 🎨 UI Components

All components built with **Tailwind CSS**:
- Cards and panels
- Tables with pagination
- Forms with validation
- Modals and dialogs
- Status badges
- Progress bars
- Charts (using Chart.js)
- Responsive navigation

## ⚙️ Configuration

### `.env` Settings

```env
# App
APP_NAME="MikroTik Dashboard"
APP_ENV=production
APP_DEBUG=false

# Database
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_DATABASE=mikrotik_dashboard

# MikroTik API
MIKROTIK_API_TIMEOUT=30
MIKROTIK_VERIFY_SSL=false
MIKROTIK_POOL_SIZE=10

# Queue & Cache
QUEUE_CONNECTION=redis
CACHE_DRIVER=redis

# Email (for notifications)
MAIL_MAILER=smtp
MAIL_HOST=smtp.mailtrap.io
```

## 🚀 Deployment

### Production Deployment

1. **Code Setup**
   ```bash
   cd /var/www/mikrotik-dashboard
   composer install --no-dev
   npm run build
   php artisan config:cache
   php artisan route:cache
   php artisan view:cache
   ```

2. **Permissions**
   ```bash
   sudo chown -R www-data:www-data .
   chmod -R 755 .
   chmod -R 775 storage bootstrap/cache
   ```

3. **Web Server** (Nginx example)
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com;

       root /var/www/mikrotik-dashboard/public;
       index index.php;

       location ~ \.php$ {
           fastcgi_pass unix:/var/run/php-fpm.sock;
           fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
           include fastcgi_params;
       }

       location / {
           try_files $uri $uri/ /index.php?$query_string;
       }
   }
   ```

4. **SSL/TLS**
   - Use Let's Encrypt for free SSL certificates
   - Redirect HTTP to HTTPS

5. **Backup**
   ```bash
   # Database backup
   mysqldump -u root -p mikrotik_dashboard > backup.sql

   # Files backup
   tar -czf mikrotik-dashboard-backup.tar.gz /var/www/mikrotik-dashboard
   ```

## 🧪 Testing

```bash
# Run tests
php artisan test

# With coverage
php artisan test --coverage
```

## 📚 API Documentation

### Available Roles & Permissions

**Super Admin**
- All permissions

**Network Admin**
- routers: view, create, update, sync
- interfaces: view, manage
- firewall: view, manage
- queue: view, manage
- vpn: view, manage
- users: view
- audit: view

**Operator**
- routers: view, sync
- interfaces: view, manage
- firewall: view
- queue: view
- vpn: view
- audit: view

**Viewer**
- View-only access to all features

## 🐛 Troubleshooting

### Connection Issues
- Verify API service is enabled on router
- Check firewall rules allow API port
- Verify username/password are correct
- Ensure user has appropriate API permissions

### Performance Issues
- Use Redis for caching and queues
- Sync data periodically, not continuously
- Increase `MIKROTIK_API_TIMEOUT` if routers are slow
- Use `php artisan optimize` for production

### Database Issues
```bash
# Reset database
php artisan migrate:reset
php artisan migrate
php artisan db:seed

# Check migrations
php artisan migrate:status
```

## 🤝 Contributing

Contributions are welcome! Please follow Laravel coding standards and include tests for new features.

## 📄 License

This project is licensed under the MIT License.

## 📧 Support

For issues, bugs, or feature requests, please create an issue or contact the development team.

## 🎯 Roadmap

- [ ] REST API for external integrations
- [ ] WebSocket real-time updates
- [ ] Advanced reporting and analytics
- [ ] Backup & restore functionality
- [ ] Multi-site management
- [ ] Mobile native app
- [ ] Prometheus metrics export
- [ ] Slack/Teams notifications

---

**Built with ❤️ for network administrators**

**Version:** 1.0.0  
**Last Updated:** March 2026
