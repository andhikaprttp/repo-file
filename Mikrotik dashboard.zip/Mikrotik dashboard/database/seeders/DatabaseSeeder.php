<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Role;
use App\Models\Permission;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Create roles
        $roles = [
            [
                'name' => 'super_admin',
                'display_name' => 'Super Administrator',
                'description' => 'Full system access',
            ],
            [
                'name' => 'network_admin',
                'display_name' => 'Network Administrator',
                'description' => 'Network management and configuration',
            ],
            [
                'name' => 'operator',
                'display_name' => 'NOC Operator',
                'description' => 'Monitoring and basic operations',
            ],
            [
                'name' => 'viewer',
                'display_name' => 'Read-Only Viewer',
                'description' => 'View-only access',
            ],
        ];

        foreach ($roles as $role) {
            Role::create($role);
        }

        // Create permissions
        $permissions = [
            // Router permissions
            ['name' => 'routers.view', 'display_name' => 'View Routers', 'category' => 'routers'],
            ['name' => 'routers.create', 'display_name' => 'Create Routers', 'category' => 'routers'],
            ['name' => 'routers.update', 'display_name' => 'Update Routers', 'category' => 'routers'],
            ['name' => 'routers.delete', 'display_name' => 'Delete Routers', 'category' => 'routers'],
            ['name' => 'routers.sync', 'display_name' => 'Sync Routers', 'category' => 'routers'],

            // Interface permissions
            ['name' => 'interfaces.view', 'display_name' => 'View Interfaces', 'category' => 'interfaces'],
            ['name' => 'interfaces.manage', 'display_name' => 'Manage Interfaces', 'category' => 'interfaces'],

            // Firewall permissions
            ['name' => 'firewall.view', 'display_name' => 'View Firewall Rules', 'category' => 'firewall'],
            ['name' => 'firewall.manage', 'display_name' => 'Manage Firewall Rules', 'category' => 'firewall'],

            // Queue permissions
            ['name' => 'queue.view', 'display_name' => 'View Queues', 'category' => 'queue'],
            ['name' => 'queue.manage', 'display_name' => 'Manage Queues', 'category' => 'queue'],

            // VPN permissions
            ['name' => 'vpn.view', 'display_name' => 'View VPN', 'category' => 'vpn'],
            ['name' => 'vpn.view_secrets', 'display_name' => 'View VPN Secrets', 'category' => 'vpn'],
            ['name' => 'vpn.create_secret', 'display_name' => 'Create VPN Secrets', 'category' => 'vpn'],
            ['name' => 'vpn.manage', 'display_name' => 'Manage VPN', 'category' => 'vpn'],

            // User permissions
            ['name' => 'users.view', 'display_name' => 'View Users', 'category' => 'users'],
            ['name' => 'users.create', 'display_name' => 'Create Users', 'category' => 'users'],
            ['name' => 'users.update', 'display_name' => 'Update Users', 'category' => 'users'],
            ['name' => 'users.delete', 'display_name' => 'Delete Users', 'category' => 'users'],

            // Audit permissions
            ['name' => 'audit.view', 'display_name' => 'View Audit Logs', 'category' => 'audit'],
        ];

        foreach ($permissions as $permission) {
            Permission::create($permission);
        }

        // Assign permissions to roles
        $superAdminRole = Role::where('name', 'super_admin')->first();
        $superAdminRole->permissions()->sync(Permission::pluck('id'));

        $networkAdminRole = Role::where('name', 'network_admin')->first();
        $networkAdminPerms = Permission::whereIn('name', [
            'routers.view', 'routers.create', 'routers.update', 'routers.sync',
            'interfaces.view', 'interfaces.manage',
            'firewall.view', 'firewall.manage',
            'queue.view', 'queue.manage',
            'vpn.view', 'vpn.view_secrets', 'vpn.create_secret',
            'users.view', 'audit.view',
        ])->pluck('id');
        $networkAdminRole->permissions()->sync($networkAdminPerms);

        $operatorRole = Role::where('name', 'operator')->first();
        $operatorPerms = Permission::whereIn('name', [
            'routers.view', 'routers.sync',
            'interfaces.view', 'interfaces.manage',
            'firewall.view',
            'queue.view',
            'vpn.view',
            'audit.view',
        ])->pluck('id');
        $operatorRole->permissions()->sync($operatorPerms);

        $viewerRole = Role::where('name', 'viewer')->first();
        $viewerPerms = Permission::whereIn('name', [
            'routers.view',
            'interfaces.view',
            'firewall.view',
            'queue.view',
            'vpn.view',
            'audit.view',
        ])->pluck('id');
        $viewerRole->permissions()->sync($viewerPerms);

        // Create default super admin user
        $user = User::create([
            'name' => 'Administrator',
            'email' => 'admin@mikrotik.local',
            'password' => Hash::make('Password@123'),
            'is_active' => true,
        ]);

        $user->roles()->attach($superAdminRole);

        $this->command->info('Database seeded successfully!');
        $this->command->info("Default Admin User: admin@mikrotik.local / Password@123");
    }
}
