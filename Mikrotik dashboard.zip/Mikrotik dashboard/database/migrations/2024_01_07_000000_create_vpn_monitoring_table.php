<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ppp_secrets', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->string('name')->unique();
            $table->string('service'); // pppoe, pptp, l2tp, ovpn, etc
            $table->text('password'); // Encrypted
            $table->ipAddress('local_address')->nullable();
            $table->ipAddress('remote_address')->nullable();
            $table->integer('disabled')->default(0);
            $table->text('comment')->nullable();
            $table->timestamps();
            $table->index('router_id');
        });

        Schema::create('ppp_sessions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('service'); // pppoe, pptp, l2tp, ovpn
            $table->ipAddress('remote_address')->nullable();
            $table->ipAddress('local_address')->nullable();
            $table->bigInteger('uptime')->default(0); // seconds
            $table->bigInteger('tx_bytes')->default(0);
            $table->bigInteger('rx_bytes')->default(0);
            $table->timestamp('connected_at');
            $table->timestamps();
            $table->index(['router_id', 'service']);
        });

        Schema::create('system_stats', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->integer('cpu_usage')->default(0); // percentage
            $table->integer('memory_usage')->default(0); // percentage
            $table->bigInteger('memory_total')->default(0); // bytes
            $table->bigInteger('memory_free')->default(0); // bytes
            $table->bigInteger('uptime')->default(0); // seconds
            $table->integer('temperature')->nullable(); // celsius
            $table->timestamp('recorded_at');
            $table->timestamps();
            $table->index(['router_id', 'recorded_at']);
        });

        Schema::create('activity_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('router_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('action'); // router_added, config_changed, etc
            $table->string('entity_type')->nullable(); // Router, Interface, Firewall
            $table->unsignedBigInteger('entity_id')->nullable();
            $table->text('changes')->nullable(); // JSON
            $table->string('ip_address')->nullable();
            $table->text('user_agent')->nullable();
            $table->timestamps();
            $table->index(['user_id', 'created_at']);
            $table->index(['router_id', 'created_at']);
        });

        Schema::create('audit_logs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->constrained()->cascadeOnDelete();
            $table->string('event_type'); // login, failed_login, permission_change, etc
            $table->string('description');
            $table->ipAddress('ip_address')->nullable();
            $table->string('user_agent')->nullable();
            $table->string('status')->default('success'); // success, failed
            $table->text('details')->nullable(); // JSON
            $table->timestamps();
            $table->index(['created_at', 'event_type']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('audit_logs');
        Schema::dropIfExists('activity_logs');
        Schema::dropIfExists('system_stats');
        Schema::dropIfExists('ppp_sessions');
        Schema::dropIfExists('ppp_secrets');
    }
};
