<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ip_addresses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('interface_id')->constrained()->cascadeOnDelete();
            $table->string('address'); // IP/CIDR
            $table->string('gateway')->nullable();
            $table->string('dns')->nullable();
            $table->string('network')->nullable();
            $table->boolean('disabled')->default(false);
            $table->text('comment')->nullable();
            $table->timestamps();
            $table->unique(['interface_id', 'address']);
        });

        Schema::create('dhcp_servers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('interface_id')->constrained()->cascadeOnDelete();
            $table->ipAddress('address');
            $table->string('name')->nullable();
            $table->boolean('disabled')->default(false);
            $table->text('comment')->nullable();
            $table->timestamps();
            $table->unique(['interface_id', 'address']);
        });

        Schema::create('dhcp_leases', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->ipAddress('address');
            $table->string('mac_address');
            $table->string('client_id')->nullable();
            $table->string('host_name')->nullable();
            $table->timestamp('expires_at')->nullable();
            $table->string('status')->default('active'); // active, expired,blocked
            $table->boolean('disabled')->default(false);
            $table->timestamps();
            $table->index(['router_id', 'address']);
        });

        Schema::create('static_routes', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->string('destination');
            $table->string('gateway');
            $table->string('distance')->nullable();
            $table->boolean('disabled')->default(false);
            $table->text('comment')->nullable();
            $table->timestamps();
            $table->index('router_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('static_routes');
        Schema::dropIfExists('dhcp_leases');
        Schema::dropIfExists('dhcp_servers');
        Schema::dropIfExists('ip_addresses');
    }
};
