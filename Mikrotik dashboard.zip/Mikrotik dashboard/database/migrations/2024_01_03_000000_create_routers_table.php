<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('routers', function (Blueprint $table) {
            $table->id();
            $table->string('name')->unique();
            $table->string('host_ip');
            $table->integer('port')->default(8728);
            $table->string('identity')->nullable();
            $table->string('version')->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamp('last_connection_at')->nullable();
            $table->timestamp('last_sync_at')->nullable();
            $table->string('status')->default('offline'); // online, offline, error
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->softDeletes();
            $table->index(['is_active', 'status']);
            $table->index('host_ip');
        });

        Schema::create('router_credentials', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->string('username');
            $table->text('password'); // Encrypted
            $table->boolean('use_ssl')->default(false);
            $table->text('private_key')->nullable(); // For certificate-based auth
            $table->timestamps();
            $table->unique('router_id');
        });

        Schema::create('interfaces', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('type'); // ether, wifi, ppp, bridge, etc
            $table->boolean('enabled')->default(true);
            $table->string('mac_address')->nullable();
            $table->bigInteger('mtu')->default(1500);
            $table->text('comment')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->index(['router_id', 'enabled']);
            $table->unique(['router_id', 'name']);
        });

        Schema::create('interface_stats', function (Blueprint $table) {
            $table->id();
            $table->foreignId('interface_id')->constrained()->cascadeOnDelete();
            $table->bigInteger('rx_bytes')->default(0);
            $table->bigInteger('tx_bytes')->default(0);
            $table->bigInteger('rx_packets')->default(0);
            $table->bigInteger('tx_packets')->default(0);
            $table->bigInteger('rx_errors')->default(0);
            $table->bigInteger('tx_errors')->default(0);
            $table->integer('rx_rate')->default(0); // Kbps
            $table->integer('tx_rate')->default(0); // Kbps
            $table->timestamp('recorded_at');
            $table->timestamps();
            $table->index(['interface_id', 'recorded_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('interface_stats');
        Schema::dropIfExists('interfaces');
        Schema::dropIfExists('router_credentials');
        Schema::dropIfExists('routers');
    }
};
