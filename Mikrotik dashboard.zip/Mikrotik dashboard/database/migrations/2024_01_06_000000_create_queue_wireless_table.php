<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('simple_queues', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->string('name')->unique();
            $table->string('target');
            $table->string('direction')->default('both'); // up, down, both
            $table->bigInteger('limit_tx')->nullable(); // bits/sec
            $table->bigInteger('limit_rx')->nullable(); // bits/sec
            $table->string('burst_limit_tx')->nullable();
            $table->string('burst_limit_rx')->nullable();
            $table->boolean('disabled')->default(false);
            $table->text('comment')->nullable();
            $table->timestamps();
            $table->index('router_id');
        });

        Schema::create('queue_trees', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->integer('parent')->nullable();
            $table->string('name')->nullable();
            $table->string('packet_mark')->nullable();
            $table->string('priority')->default('8');
            $table->bigInteger('limit_at')->nullable();
            $table->bigInteger('max_limit')->nullable();
            $table->bigInteger('burst_limit')->nullable();
            $table->string('burst_time')->nullable();
            $table->boolean('disabled')->default(false);
            $table->timestamps();
            $table->index('router_id');
        });

        Schema::create('wireless_interfaces', function (Blueprint $table) {
            $table->id();
            $table->foreignId('interface_id')->constrained()->cascadeOnDelete();
            $table->string('ssid');
            $table->string('mode'); // ap-bridge, station, monitor, etc
            $table->string('band'); // 2ghz-b, 2ghz-g, 5ghz, etc
            $table->integer('channel')->nullable();
            $table->integer('tx_power')->nullable(); // dBm
            $table->string('antenna_gain')->nullable();
            $table->string('security_profile')->nullable();
            $table->integer('client_count')->default(0);
            $table->timestamps();
            $table->unique('interface_id');
        });

        Schema::create('wireless_clients', function (Blueprint $table) {
            $table->id();
            $table->foreignId('wireless_interface_id')->constrained()->cascadeOnDelete();
            $table->string('mac_address');
            $table->string('interface')->nullable();
            $table->integer('signal_strength')->nullable(); // dBm
            $table->integer('signal_to_noise_ratio')->nullable(); // dB
            $table->bigInteger('rx_rate')->nullable(); // Kbps
            $table->bigInteger('tx_rate')->nullable(); // Kbps
            $table->bigInteger('rx_bytes')->default(0);
            $table->bigInteger('tx_bytes')->default(0);
            $table->timestamp('connected_at')->nullable();
            $table->timestamps();
            $table->index(['wireless_interface_id', 'mac_address']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('wireless_clients');
        Schema::dropIfExists('wireless_interfaces');
        Schema::dropIfExists('queue_trees');
        Schema::dropIfExists('simple_queues');
    }
};
