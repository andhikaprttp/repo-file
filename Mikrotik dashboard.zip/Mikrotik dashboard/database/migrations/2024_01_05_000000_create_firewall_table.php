<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('firewall_filters', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->integer('chain_position')->nullable();
            $table->string('chain'); // input, output, forward
            $table->string('in_interface')->nullable();
            $table->string('out_interface')->nullable();
            $table->string('src_address')->nullable();
            $table->string('dst_address')->nullable();
            $table->string('src_port')->nullable();
            $table->string('dst_port')->nullable();
            $table->string('protocol')->nullable(); // tcp, udp, icmp
            $table->string('connection_state')->nullable();
            $table->string('action')->default('drop'); // drop, accept, log
            $table->boolean('disabled')->default(false);
            $table->text('comment')->nullable();
            $table->timestamps();
            $table->index(['router_id', 'chain']);
        });

        Schema::create('firewall_nats', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->integer('chain_position')->nullable();
            $table->string('chain'); // srcnat, dstnat, masquerade
            $table->string('in_interface')->nullable();
            $table->string('out_interface')->nullable();
            $table->string('src_address')->nullable();
            $table->string('dst_address')->nullable();
            $table->string('action');
            $table->string('to_addresses')->nullable();
            $table->string('to_ports')->nullable();
            $table->boolean('disabled')->default(false);
            $table->text('comment')->nullable();
            $table->timestamps();
            $table->index(['router_id', 'chain']);
        });

        Schema::create('firewall_mangles', function (Blueprint $table) {
            $table->id();
            $table->foreignId('router_id')->constrained()->cascadeOnDelete();
            $table->integer('chain_position')->nullable();
            $table->string('chain');
            $table->string('in_interface')->nullable();
            $table->string('out_interface')->nullable();
            $table->string('action');
            $table->string('new_mark')->nullable();
            $table->boolean('disabled')->default(false);
            $table->text('comment')->nullable();
            $table->timestamps();
            $table->index(['router_id', 'chain']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('firewall_mangles');
        Schema::dropIfExists('firewall_nats');
        Schema::dropIfExists('firewall_filters');
    }
};
