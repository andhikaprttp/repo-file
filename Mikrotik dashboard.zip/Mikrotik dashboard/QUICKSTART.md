# 🚀 Quick Start Guide

## Installation in 5 Minutes

### 1. Prerequisites Check
```bash
php --version          # PHP 8.2+
composer --version     # Latest
node --version         # 16+
mysql --version        # 5.7+
```

### 2. Clone Project
```bash
git clone https://github.com/yourusername/mikrotik-dashboard.git
cd mikrotik-dashboard
```

### 3. Install Dependencies
```bash
composer install
npm install
```

### 4. Configure Environment
```bash
cp .env.example .env
php artisan key:generate
```

Edit `.env` with your database credentials:
```ini
DB_DATABASE=mikrotik_dashboard
DB_USERNAME=root
DB_PASSWORD=yourpassword
```

### 5. Setup Database
```bash
php artisan migrate
php artisan db:seed
```

### 6. Build Assets
```bash
npm run dev
```

### 7. Run Server
```bash
php artisan serve
```

Visit: `http://localhost:8000`

**Default Login:**
- Email: `admin@mikrotik.local`
- Password: `Password@123`

---

## First Router Setup

1. Go to Dashboard → Add Router
2. Enter your MikroTik device IP and credentials
3. Use port **8728** (API) or **8729** (API-SSL)
4. Click "Add Router"
5. Dashboard automatically tests and syncs data

---

## MikroTik Router Configuration

### Enable API on RouterOS

**Via CLI:**
```
/ip/service/enable api
/user/add name=dashboard password=YourPassword group=full
```

**Via WebFig:**
1. IP → Services
2. Find "api" and click enable
3. System → Users → Add new user
4. Set name: `dashboard`
5. Set group: `full` (or configure custom permissions)

---

## Troubleshooting

### Issue: "SQLSTATE[HY000]: General error"
**Solution:** 
```bash
php artisan migrate:reset
php artisan migrate
php artisan db:seed
```

### Issue: "Cannot connect to router"
**Check:**
- Router IP is correct
- API port (8728/8729) is open
- API service is enabled on router
- Credentials are correct
- Firewall allows connection

### Issue: "No routes defined"
**Solution:**
```bash
php artisan route:cache
php artisan route:clear
```

---

## Docker Deployment (Optional)

### docker-compose.yml
```yaml
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
    ports:
      - "8000:8000"
    environment:
      - DB_CONNECTION=mysql
      - DB_HOST=db
      - DB_DATABASE=mikrotik
      - DB_USERNAME=root
      - DB_PASSWORD=secret
    depends_on:
      - db
      - redis
    volumes:
      - .:/var/www

  db:
    image: mysql:8.0
    environment:
      MYSQL_ROOT_PASSWORD: secret
      MYSQL_DATABASE: mikrotik
    ports:
      - "3306:3306"

  redis:
    image: redis:7.0
    ports:
      - "6379:6379"
```

Run with:
```bash
docker-compose up -d
```

---

## Next Steps

1. ✅ Add test routers
2. ✅ Create additional users with different roles
3. ✅ Configure firewall rules monitoring
4. ✅ Set up queue management
5. ✅ Enable activity logging
6. ✅ Schedule automatic data syncs

---

Need help? Check [README.md](README.md) for detailed documentation.
