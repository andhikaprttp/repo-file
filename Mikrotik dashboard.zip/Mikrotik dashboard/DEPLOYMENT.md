# 📦 Deployment Guide

## Production Deployment Checklist

### Pre-Deployment
- [ ] All code committed to version control
- [ ] Environment variables configured
- [ ] Database backed up
- [ ] Tests passing
- [ ] Security audit completed

---

## Platform-Specific Deployments

### 🐧 Linux (Ubuntu/Debian)

#### 1. Server Setup
```bash
# Update system
sudo apt update && sudo apt upgrade -y

# Install required packages
sudo apt install -y php8.2 php8.2-fpm php8.2-mysql php8.2-gd php8.2-zip php8.2-curl
sudo apt install -y mysql-server nginx redis-server
sudo apt install -y nodejs npm
```

#### 2. Create Application Directory
```bash
sudo mkdir -p /var/www/mikrotik-dashboard
sudo chown -R $USER:$USER /var/www/mikrotik-dashboard
cd /var/www/mikrotik-dashboard
```

#### 3. Deploy Code
```bash
git clone https://github.com/yourusername/mikrotik-dashboard.git .
composer install --no-dev --optimize-autoloader
npm install
npm run build
```

#### 4. Configure Environment
```bash
cp .env.example .env
php artisan key:generate

# Edit .env with production settings
nano .env
```

#### 5. Database Setup
```bash
# Create MySQL database
mysql -u root -p -e "CREATE DATABASE mikrotik_dashboard CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"
mysql -u root -p -e "CREATE USER 'mikrotik'@'localhost' IDENTIFIED BY 'strong_password';"
mysql -u root -p -e "GRANT ALL PRIVILEGES ON mikrotik_dashboard.* TO 'mikrotik'@'localhost';"

# Run migrations
php artisan migrate --force
php artisan db:seed --force
```

#### 6. Set Permissions
```bash
sudo chown -R www-data:www-data /var/www/mikrotik-dashboard
chmod -R 755 /var/www/mikrotik-dashboard
chmod -R 775 /var/www/mikrotik-dashboard/storage
chmod -R 775 /var/www/mikrotik-dashboard/bootstrap/cache
```

#### 7. Nginx Configuration
Create `/etc/nginx/sites-available/mikrotik`:

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;
    root /var/www/mikrotik-dashboard/public;
    index index.php index.html;

    # Redirect to HTTPS
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;
    root /var/www/mikrotik-dashboard/public;
    index index.php index.html;

    # SSL Certificates
    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;

    # Security Headers
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-XSS-Protection "1; mode=block" always;

    # Gzip Compression
    gzip on;
    gzip_types text/plain text/css text/javascript application/json;

    # PHP Handling
    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.2-fpm.sock;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        fastcgi_param PATH_TRANSLATED $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }

    # Static files
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg|webp|woff|woff2)$ {
        expires 365d;
        add_header Cache-Control "public, immutable";
    }

    # Laravel routing
    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    # Deny access to sensitive files
    location ~ /\.env {
        deny all;
        return 404;
    }

    location ~ /\.git {
        deny all;
        return 404;
    }
}
```

Enable site:
```bash
sudo ln -s /etc/nginx/sites-available/mikrotik /etc/nginx/sites-enabled/
sudo systemctl restart nginx
```

#### 8. SSL Certificate (Let's Encrypt)
```bash
sudo apt install certbot python3-certbot-nginx -y
sudo certbot certonly --nginx -d yourdomain.com -d www.yourdomain.com
```

#### 9. PHP-FPM Configuration
Edit `/etc/php/8.2/fpm/php.ini`:
```ini
memory_limit = 512M
upload_max_filesize = 100M
post_max_size = 100M
max_execution_time = 300
```

Restart PHP-FPM:
```bash
sudo systemctl restart php8.2-fpm
```

#### 10. Set Up Cron Jobs
```bash
sudo crontab -e

# Add:
* * * * * cd /var/www/mikrotik-dashboard && php artisan schedule:run >> /dev/null 2>&1
```

#### 11. Systemd Service (Queue Worker)
Create `/etc/systemd/system/laravel-queue.service`:

```ini
[Unit]
Description=Laravel Queue Worker
After=network.target

[Service]
Type=simple
User=www-data
WorkingDirectory=/var/www/mikrotik-dashboard
ExecStart=/usr/bin/php /var/www/mikrotik-dashboard/artisan queue:work redis --sleep=3 --tries=3
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Enable:
```bash
sudo systemctl enable laravel-queue
sudo systemctl start laravel-queue
```

---

### 🐳 Docker Deployment

#### 1. Dockerfile
Create `Dockerfile`:

```dockerfile
FROM php:8.2-fpm-alpine

# Install dependencies
RUN apk add --no-cache \
    build-base \
    mysql-client \
    libpng-dev \
    libjpeg-turbo-dev \
    freetype-dev \
    zip \
    unzip \
    git \
    curl \
    nodejs \
    npm

# Install PHP extensions
RUN docker-php-ext-install \
    pdo \
    pdo_mysql \
    gd \
    zip

# Install Composer
COPY --from=composer:latest /usr/bin/composer /usr/bin/composer

# Set working directory
WORKDIR /var/www

# Copy code
COPY . .

# Install dependencies
RUN composer install --no-dev && \
    npm install && \
    npm run build

# Permissions
RUN chown -R www-data:www-data /var/www

CMD ["php-fpm"]
```

#### 2. Docker Compose
Create `docker-compose.yml`:

```yaml
version: '3.8'

services:
  app:
    build: .
    container_name: mikrotik-app
    restart: unless-stopped
    working_dir: /var/www
    volumes:
      - ./:/var/www
    depends_on:
      - db
      - redis
    networks:
      - mikrotik

  db:
    image: mysql:8.0
    container_name: mikrotik-db
    restart: unless-stopped
    environment:
      MYSQL_DATABASE: ${DB_DATABASE}
      MYSQL_ROOT_PASSWORD: ${DB_PASSWORD}
      MYSQL_PASSWORD: ${DB_PASSWORD}
      MYSQL_USER: ${DB_USERNAME}
    volumes:
      - dbdata:/var/lib/mysql
    networks:
      - mikrotik

  redis:
    image: redis:7.0-alpine
    container_name: mikrotik-redis
    restart: unless-stopped
    networks:
      - mikrotik

  nginx:
    image: nginx:alpine
    container_name: mikrotik-nginx
    restart: unless-stopped
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./:/var/www
      - ./docker/nginx.conf:/etc/nginx/conf.d/default.conf
      - ./certs:/etc/nginx/certs
    depends_on:
      - app
    networks:
      - mikrotik

volumes:
  dbdata:

networks:
  mikrotik:
    driver: bridge
```

#### 3. Deploy with Docker
```bash
docker-compose up -d
docker-compose exec app php artisan migrate --force
docker-compose exec app php artisan db:seed --force
```

---

### ☁️ Cloud Platforms

#### AWS EC2
1. Launch Ubuntu 22.04 instance
2. Follow Linux deployment steps above
3. Use AWS RDS for MySQL
4. Use ElastiCache for Redis

#### DigitalOcean
1. Create Ubuntu Droplet
2. Follow Linux deployment steps
3. Use DigitalOcean Managed Database
4. Use DNS pointing

#### Heroku
Not recommended due to stateless nature and router credential storage requirements.

---

## Post-Deployment

### 1. Verify Installation
```bash
# Check status
php artisan health

# Test API connection
php artisan tinker
> \App\Models\Router::first()->sync();

# Check queue
php artisan queue:work --stop-when-empty
```

### 2. Set Cache
```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan optimize
```

### 3. Setup Monitoring
- Monitor disk space
- Monitor database size
- Monitor error logs
- Setup uptime monitoring
- Setup backup schedules

### 4. Backup Strategy
```bash
# Daily database backup
0 2 * * * mysqldump -u mikrotik -p mikrotik_dashboard | gzip > /backups/db-$(date +\%Y\%m\%d).sql.gz

# Weekly application backup
0 3 * * 0 tar -czf /backups/app-$(date +\%Y\%m\%d).tar.gz /var/www/mikrotik-dashboard
```

---

## Environmental Variables

### Production `.env`
```env
APP_NAME="MikroTik Dashboard"
APP_ENV=production
APP_DEBUG=false
APP_KEY=base64:xxxxx
APP_URL=https://yourdomain.com

DB_CONNECTION=mysql
DB_HOST=db.example.com
DB_PORT=3306
DB_DATABASE=mikrotik_dashboard
DB_USERNAME=mikrotik
DB_PASSWORD=strong_password

CACHE_DRIVER=redis
QUEUE_CONNECTION=redis
SESSION_DRIVER=cookie

REDIS_HOST=redis.example.com
REDIS_PORT=6379

MAIL_MAILER=smtp
MAIL_HOST=smtp.gmail.com
MAIL_PORT=587
MAIL_USERNAME=your-email@gmail.com
MAIL_PASSWORD=app-password
MAIL_ENCRYPTION=tls

MIKROTIK_API_TIMEOUT=30
MIKROTIK_VERIFY_SSL=false

LOG_CHANNEL=stack
LOG_LEVEL=error
```

---

## Troubleshooting Deployment

### Issue: "The system has failed to refresh file statuses"
```bash
php artisan cache:clear
php artisan config:clear
php artisan view:clear
```

### Issue: Permission denied errors
```bash
sudo chown -R www-data:www-data /var/www/mikrotik-dashboard
sudo chmod -R 775 /var/www/mikrotik-dashboard/storage
```

### Issue: Database connection errors
- Verify database credentials in .env
- Check MySQL is running: `sudo systemctl status mysql`
- Verify network access to database

### Issue: Slow response times
- Check database indexes: `php artisan migrate`
- Enable query caching: `php artisan config:cache`
- Monitor slow queries: `SET GLOBAL slow_query_log = 'ON';`

---

## Security Hardening

1. **SSH Hardening**
   ```bash
   # Edit /etc/ssh/sshd_config
   PermitRootLogin no
   PasswordAuthentication no
   PubkeyAuthentication yes
   ```

2. **Firewall Setup**
   ```bash
   sudo ufw allow 22/tcp
   sudo ufw allow 80/tcp
   sudo ufw allow 443/tcp
   sudo ufw enable
   ```

3. **Regular Updates**
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

4. **Security Monitoring**
   - Setup logwatch
   - Monitor access logs
   - Setup intrusion detection (fail2ban)

---

## Maintenance

### Daily
- Monitor error logs
- Check disk space
- Verify backups completed

### Weekly
- Review audit logs
- Check database size
- Review user access

### Monthly
- Rotate logs
- Update dependencies: `composer update`
- Review security updates

---

End of deployment guide. For more help, see README.md or QUICKSTART.md
