import Alpine from 'alpinejs';
import Chart from 'chart.js/auto';

window.Alpine = Alpine;
window.Chart = Chart;

Alpine.start();

// Global configuration
axios.defaults.headers.common['X-CSRF-TOKEN'] = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');

// Dark mode
function toggleDarkMode() {
    const isDark = document.documentElement.classList.toggle('dark');
    localStorage.setItem('dark-mode', isDark);
}

window.toggleDarkMode = toggleDarkMode;

// Auto-refresh stats (optional)
const autoRefreshInterval = 300000; // 5 minutes

document.addEventListener('DOMContentLoaded', () => {
    // Console message
    console.log('%c🛜 MikroTik Dashboard', 'font-size: 18px; font-weight: bold; color: #2563eb;');
    console.log('%cVersion 1.0.0', 'color: #6b7280; font-size: 12px;');
});

// Export for use in views
export { toggleDarkMode };
