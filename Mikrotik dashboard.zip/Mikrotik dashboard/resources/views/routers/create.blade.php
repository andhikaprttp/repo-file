@extends('layouts.app')

@section('title', 'Add Router')
@section('page_title', 'Add New Router')
@section('page_subtitle', 'Configure connection to your MikroTik RouterOS device')

@section('content')

<div class="max-w-3xl">
    <div class="bg-white dark:bg-slate-800 rounded-lg shadow p-8">
        
        <form action="{{ route('routers.store') }}" method="POST" class="space-y-6">
            @csrf

            <div class="grid grid-cols-2 gap-6">
                <!-- Router Name -->
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                        Router Name <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="name" value="{{ old('name') }}" 
                           placeholder="e.g., Main Router, Branch Office 1"
                           class="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('name') border-red-500 @enderror"
                           required>
                    @error('name')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Host IP -->
                <div>
                    <label class="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                        Host IP Address <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="host_ip" value="{{ old('host_ip') }}" 
                           placeholder="192.168.1.1"
                           class="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('host_ip') border-red-500 @enderror"
                           required>
                    @error('host_ip')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- API Port -->
                <div>
                    <label class="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                        API Port
                    </label>
                    <input type="number" name="port" value="{{ old('port', 8728) }}" 
                           placeholder="8728"
                           class="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('port') border-red-500 @enderror"
                           min="1" max="65535">
                    @error('port')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                    <p class="text-xs text-slate-500 dark:text-slate-400 mt-1">Default: 8728 (API), 8729 (API-SSL)</p>
                </div>

                <!-- Username -->
                <div>
                    <label class="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                        API Username <span class="text-red-500">*</span>
                    </label>
                    <input type="text" name="username" value="{{ old('username', 'admin') }}" 
                           placeholder="admin"
                           class="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('username') border-red-500 @enderror"
                           required>
                    @error('username')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Password -->
                <div>
                    <label class="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                        API Password <span class="text-red-500">*</span>
                    </label>
                    <input type="password" name="password" 
                           placeholder="••••••••"
                           class="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('password') border-red-500 @enderror"
                           required>
                    @error('password')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- SSL Toggle -->
                <div class="col-span-2 flex items-center">
                    <input type="checkbox" name="use_ssl" value="1" id="use_ssl"
                           class="w-4 h-4 rounded border-slate-300 text-blue-600 focus:ring-2 focus:ring-blue-500">
                    <label for="use_ssl" class="ml-3 text-sm font-medium text-slate-700 dark:text-slate-300">
                        Use SSL/TLS (API-SSL on port 8729)
                    </label>
                </div>

                <!-- Notes -->
                <div class="col-span-2">
                    <label class="block text-sm font-medium text-slate-900 dark:text-white mb-2">
                        Notes
                    </label>
                    <textarea name="notes" rows="3" placeholder="Add any notes about this router..." 
                              class="w-full px-4 py-2 border border-slate-300 dark:border-slate-600 rounded-lg bg-white dark:bg-slate-700 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 focus:border-transparent @error('notes') border-red-500 @enderror"></textarea>
                    @error('notes')
                        <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Info Box -->
            <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                <p class="text-sm text-blue-800 dark:text-blue-300">
                    <strong>Note:</strong> Make sure your MikroTik RouterOS has API access enabled. 
                    The user account must have appropriate permissions for accessing network configuration.
                </p>
            </div>

            <!-- Buttons -->
            <div class="flex gap-4">
                <button type="submit" 
                        class="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition font-medium">
                    Add Router
                </button>
                <a href="{{ route('routers.index') }}" 
                   class="flex-1 px-4 py-2 bg-slate-200 dark:bg-slate-700 hover:bg-slate-300 dark:hover:bg-slate-600 text-slate-900 dark:text-white rounded-lg transition text-center font-medium">
                    Cancel
                </a>
            </div>
        </form>
    </div>

    <!-- API Setup Guide -->
    <div class="mt-8 bg-white dark:bg-slate-800 rounded-lg shadow p-8">
        <h3 class="text-lg font-semibold text-slate-900 dark:text-white mb-4">API Setup Guide</h3>
        
        <div class="space-y-4 text-sm text-slate-600 dark:text-slate-300">
            <div>
                <h4 class="font-semibold text-slate-900 dark:text-white mb-2">1. Enable API</h4>
                <p>In MikroTik WebFig or CLI, navigate to: <code class="bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded">IP → Services</code></p>
                <p>Make sure "api" service is active on port 8728 (or 8729 for SSL)</p>
            </div>

            <div>
                <h4 class="font-semibold text-slate-900 dark:text-white mb-2">2. Create API User</h4>
                <p>Navigate to: <code class="bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded">System → Users</code></p>
                <p>Create a new user with minimum permissions for dashboard access</p>
            </div>

            <div>
                <h4 class="font-semibold text-slate-900 dark:text-white mb-2">3. Test Connection</h4>
                <p>After adding the router, the dashboard will automatically test the connection and sync data</p>
            </div>
        </div>
    </div>
</div>

@endsection
