@extends('layouts.app')

@section('title', 'Routers')
@section('page_title', 'Network Routers')
@section('page_subtitle', 'Manage and monitor your MikroTik routers')

@section('header_actions')
    @if (auth()->user()->hasPermission('routers.create'))
        <a href="{{ route('routers.create') }}" 
           class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
            </svg>
            Add Router
        </a>
    @endif
@endsection

@section('content')

<div class="bg-white dark:bg-slate-800 rounded-lg shadow overflow-hidden">
    <div class="px-6 py-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
        <h3 class="text-lg font-semibold text-slate-900 dark:text-white">
            All Routers ({{ $routers->total() }})
        </h3>
        <div class="text-sm text-slate-500 dark:text-slate-400">
            Showing {{ $routers->count() }} of {{ $routers->total() }}
        </div>
    </div>

    @if ($routers->isEmpty())
        <div class="px-6 py-12 text-center">
            <svg class="w-16 h-16 mx-auto mb-4 text-slate-300 dark:text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17V7m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 0V7a2 2 0 012-2h2a2 2 0 012 2v10a2 2 0 01-2 2h-2a2 2 0 01-2-2m0 0V7a2 2 0 00-2-2H9a2 2 0 00-2 2v10a2 2 0 002 2h2a2 2 0 002-2z"/>
            </svg>
            <p class="text-slate-500 dark:text-slate-400 mb-4">No routers configured yet</p>
            @if (auth()->user()->hasPermission('routers.create'))
                <a href="{{ route('routers.create') }}" class="text-blue-600 dark:text-blue-400 hover:underline font-medium">
                    Add your first router →
                </a>
            @endif
        </div>
    @else
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50 dark:bg-slate-700/50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Router Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">IP Address</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Identity</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Version</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Last Sync</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                    @foreach ($routers as $router)
                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-500 to-blue-600 flex items-center justify-center text-white font-bold text-sm">
                                        {{ substr($router->name, 0, 1) }}
                                    </div>
                                    <a href="{{ route('routers.show', $router) }}" class="ml-4 font-medium text-slate-900 dark:text-white hover:text-blue-600">
                                        {{ $router->name }}
                                    </a>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">
                                {{ $router->host_ip }}:{{ $router->port ?? 8728 }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">
                                {{ $router->identity ?? '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">
                                {{ $router->version ?? '-' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @switch($router->status)
                                    @case('online')
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200">
                                            <span class="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></span>
                                            Online
                                        </span>
                                        @break
                                    @case('offline')
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-200">
                                            <span class="w-2 h-2 bg-orange-500 rounded-full mr-2"></span>
                                            Offline
                                        </span>
                                        @break
                                    @default
                                        <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200">
                                            <span class="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                                            Error
                                        </span>
                                @endswitch
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">
                                {{ $router->last_sync_at?->diffForHumans() ?? 'Never' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                <a href="{{ route('routers.show', $router) }}" 
                                   class="text-blue-600 dark:text-blue-400 hover:text-blue-700 dark:hover:text-blue-300">
                                    View
                                </a>
                                @if (auth()->user()->hasPermission('routers.update'))
                                    <a href="{{ route('routers.edit', $router) }}" 
                                       class="text-slate-600 dark:text-slate-400 hover:text-slate-700">
                                        Edit
                                    </a>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="px-6 py-4 border-t border-slate-200 dark:border-slate-700">
            {{ $routers->links() }}
        </div>
    @endif
</div>

@endsection
