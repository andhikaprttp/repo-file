@extends('layouts.app')

@section('title', 'Dashboard')
@section('page_title', 'Dashboard')
@section('page_subtitle', 'System Overview & Network Status')

@section('header_actions')
    @if (auth()->user()->hasPermission('routers.create'))
        <a href="{{ route('routers.create') }}" 
           class="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition">
            <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
            </svg>
            Add Router
        </a>
    @endif
@endsection

@section('content')

<!-- Status Overview Cards -->
<div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
    <!-- Total Routers -->
    <div class="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border-l-4 border-blue-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-slate-500 dark:text-slate-400 text-sm">Total Routers</p>
                <p class="text-3xl font-bold text-slate-900 dark:text-white mt-2">{{ $routers->count() }}</p>
            </div>
            <svg class="w-12 h-12 text-blue-500 opacity-20" fill="currentColor" viewBox="0 0 24 24">
                <path d="M9 17V7m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 0V7a2 2 0 012-2h2a2 2 0 012 2v10a2 2 0 01-2 2h-2a2 2 0 01-2-2m0 0V7a2 2 0 00-2-2H9a2 2 0 00-2 2v10a2 2 0 002 2h2a2 2 0 002-2z"/>
            </svg>
        </div>
    </div>

    <!-- Online Status -->
    <div class="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border-l-4 border-green-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-slate-500 dark:text-slate-400 text-sm">Online</p>
                <p class="text-3xl font-bold text-green-600 mt-2">{{ $onlineCount }}</p>
                <p class="text-xs text-slate-500 dark:text-slate-400 mt-2">{{ $routers->count() > 0 ? round(($onlineCount / $routers->count()) * 100) : 0 }}% uptime</p>
            </div>
            <svg class="w-12 h-12 text-green-500 opacity-20" fill="currentColor" viewBox="0 0 24 24">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"/>
            </svg>
        </div>
    </div>

    <!-- Offline Status -->
    <div class="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border-l-4 border-orange-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-slate-500 dark:text-slate-400 text-sm">Offline</p>
                <p class="text-3xl font-bold text-orange-600 mt-2">{{ $offlineCount }}</p>
            </div>
            <svg class="w-12 h-12 text-orange-500 opacity-20" fill="currentColor" viewBox="0 0 24 24">
                <path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z" clip-rule="evenodd"/>
            </svg>
        </div>
    </div>

    <!-- Total Devices -->
    <div class="bg-white dark:bg-slate-800 rounded-lg shadow p-6 border-l-4 border-purple-500">
        <div class="flex items-center justify-between">
            <div>
                <p class="text-slate-500 dark:text-slate-400 text-sm">Connected Devices</p>
                <p class="text-3xl font-bold text-purple-600 mt-2">{{ $totalDevices }}</p>
            </div>
            <svg class="w-12 h-12 text-purple-500 opacity-20" fill="currentColor" viewBox="0 0 24 24">
                <path d="M13 10V3L4 14h7v7l9-11h-7z"/>
            </svg>
        </div>
    </div>
</div>

<!-- Routers Table -->
<div class="bg-white dark:bg-slate-800 rounded-lg shadow overflow-hidden mb-8">
    <div class="px-6 py-4 border-b border-slate-200 dark:border-slate-700 flex items-center justify-between">
        <h3 class="text-lg font-semibold text-slate-900 dark:text-white">Network Routers</h3>
        <span class="text-sm text-slate-500 dark:text-slate-400">{{ $routers->count() }} total</span>
    </div>

    @if ($routers->isEmpty())
        <div class="px-6 py-12 text-center">
            <p class="text-slate-500 dark:text-slate-400 mb-4">No routers configured yet</p>
            @if (auth()->user()->hasPermission('routers.create'))
                <a href="{{ route('routers.create') }}" class="text-blue-600 hover:text-blue-700 font-medium">
                    Add your first router →
                </a>
            @endif
        </div>
    @else
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-slate-50 dark:bg-slate-700/50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Router</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">IP Address</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Version</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Interfaces</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Last Sync</th>
                        <th class="px-6 py-3 text-right text-xs font-medium text-slate-600 dark:text-slate-300 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 dark:divide-slate-700">
                    @foreach ($routers as $router)
                        <tr class="hover:bg-slate-50 dark:hover:bg-slate-700/50 transition">
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="flex items-center">
                                    <div class="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center">
                                        <svg class="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
                                            <path d="M9 17V7m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 0V7a2 2 0 012-2h2a2 2 0 012 2v10a2 2 0 01-2 2h-2a2 2 0 01-2-2m0 0V7a2 2 0 00-2-2H9a2 2 0 00-2 2v10a2 2 0 002 2h2a2 2 0 002-2z"/>
                                        </svg>
                                    </div>
                                    <div class="ml-4">
                                        <a href="{{ route('routers.show', $router) }}" class="font-medium text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400">
                                            {{ $router->name }}
                                        </a>
                                    </div>
                                </div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">{{ $router->host_ip }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">{{ $router->version ?? 'Unknown' }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">{{ $router->getActiveInterfacesCount() }}</td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                @if ($router->isOnline())
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-200">
                                        <span class="w-2 h-2 bg-green-500 rounded-full mr-2"></span>
                                        Online
                                    </span>
                                @elseif ($router->isOffline())
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-orange-100 dark:bg-orange-900/30 text-orange-800 dark:text-orange-200">
                                        <span class="w-2 h-2 bg-orange-500 rounded-full mr-2"></span>
                                        Offline
                                    </span>
                                @else
                                    <span class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-red-100 dark:bg-red-900/30 text-red-800 dark:text-red-200">
                                        <span class="w-2 h-2 bg-red-500 rounded-full mr-2"></span>
                                        Error
                                    </span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-600 dark:text-slate-300">
                                {{ $router->last_sync_at ? $router->last_sync_at->diffForHumans() : 'Never' }}
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <a href="{{ route('routers.show', $router) }}" class="text-blue-600 hover:text-blue-700 dark:hover:text-blue-400">
                                    View
                                </a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
</div>

<!-- Quick Stats -->
<div class="grid grid-cols-1 md:grid-cols-2 gap-6">
    <!-- System Performance -->
    <div class="bg-white dark:bg-slate-800 rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-slate-900 dark:text-white mb-4">System Performance</h3>
        <div class="space-y-4">
            @php
                $latestStats = collect($routers)
                    ->map(function($router) {
                        return $router->getLastSystemStats();
                    })
                    ->filter()
                    ->take(5);
            @endphp
            
            @if ($latestStats->isEmpty())
                <p class="text-slate-500 dark:text-slate-400 text-sm">No data available yet</p>
            @else
                <div class="space-y-3">
                    @foreach ($latestStats as $stat)
                        <div class="flex items-center justify-between">
                            <span class="text-sm text-slate-600 dark:text-slate-300">{{ $stat->router->name }}</span>
                            <div class="flex items-center space-x-4">
                                <div class="text-right">
                                    <p class="text-sm font-medium text-slate-900 dark:text-white">CPU: {{ $stat->cpu_usage }}%</p>
                                    <div class="w-32 h-2 bg-slate-200 dark:bg-slate-700 rounded-full mt-1 overflow-hidden">
                                        <div class="h-full bg-blue-500" style="width: {{ $stat->cpu_usage }}%"></div>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <p class="text-sm font-medium text-slate-900 dark:text-white">RAM: {{ $stat->memory_usage }}%</p>
                                    <div class="w-32 h-2 bg-slate-200 dark:bg-slate-700 rounded-full mt-1 overflow-hidden">
                                        <div class="h-full bg-purple-500" style="width: {{ $stat->memory_usage }}%"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endif
        </div>
    </div>

    <!-- Recent Activity -->
    <div class="bg-white dark:bg-slate-800 rounded-lg shadow p-6">
        <h3 class="text-lg font-semibold text-slate-900 dark:text-white mb-4">Recent Activity</h3>
        <div class="space-y-4">
            @php
                $activities = \App\Models\ActivityLog::latest()
                    ->with('user')
                    ->take(5)
                    ->get();
            @endphp

            @forelse ($activities as $activity)
                <div class="flex items-start space-x-3 text-sm">
                    <div class="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                    <div>
                        <p class="font-medium text-slate-900 dark:text-white">
                            {{ $activity->action }}
                        </p>
                        <p class="text-slate-500 dark:text-slate-400 text-xs">
                            {{ $activity->user->name }} - {{ $activity->created_at->diffForHumans() }}
                        </p>
                    </div>
                </div>
            @empty
                <p class="text-slate-500 dark:text-slate-400 text-sm">No activity yet</p>
            @endforelse
        </div>
    </div>
</div>

@endsection
