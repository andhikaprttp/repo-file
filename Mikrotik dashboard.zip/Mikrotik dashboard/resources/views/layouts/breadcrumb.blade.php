<!-- Breadcrumb Navigation -->
<nav class="flex mb-6" aria-label="Breadcrumb">
    <ol class="flex items-center space-x-2 text-sm">
        <li>
            <a href="{{ route('dashboard') }}" class="text-blue-600 dark:text-blue-400 hover:underline">
                Dashboard
            </a>
        </li>
        @if (Route::is('routers.*'))
            <li class="text-slate-400">/</li>
            <li>
                <a href="{{ route('routers.index') }}" class="text-blue-600 dark:text-blue-400 hover:underline">
                    Routers
                </a>
            </li>
            @if (Route::is('routers.show'))
                <li class="text-slate-400">/</li>
                <li class="text-slate-600 dark:text-slate-400">
                    {{ $router->name ?? 'Router' }}
                </li>
            @elseif (Route::is('routers.create'))
                <li class="text-slate-400">/</li>
                <li class="text-slate-600 dark:text-slate-400">Create</li>
            @elseif (Route::is('routers.edit'))
                <li class="text-slate-400">/</li>
                <li class="text-slate-600 dark:text-slate-400">Edit</li>
            @endif
        @elseif (Route::is('users.*'))
            <li class="text-slate-400">/</li>
            <li>
                <a href="{{ route('users.index') }}" class="text-blue-600 dark:text-blue-400 hover:underline">
                    Users
                </a>
            </li>
        @elseif (Route::is('audit-logs'))
            <li class="text-slate-400">/</li>
            <li class="text-slate-600 dark:text-slate-400">Audit Logs</li>
        @endif
    </ol>
</nav>
