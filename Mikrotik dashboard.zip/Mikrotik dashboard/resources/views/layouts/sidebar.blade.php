<!-- Sidebar Navigation -->
<nav class="p-6 space-y-2">
    <!-- Dashboard -->
    <a href="{{ route('dashboard') }}" 
       class="flex items-center px-4 py-2 rounded-lg transition {{ Route::is('dashboard') ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700' }}">
        <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-3m0 0l7-4 7 4M5 9v10a1 1 0 001 1h12a1 1 0 001-1V9m-9 3l3 3m0 0l3-3m-3 3v-3"/>
        </svg>
        Dashboard
    </a>

    <!-- Routers -->
    @if (auth()->user()->hasPermission('routers.view'))
        <a href="{{ route('routers.index') }}"
           class="flex items-center px-4 py-2 rounded-lg transition {{ Route::is('routers.*') ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400' : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700' }}">
            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17V7m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 0V7a2 2 0 012-2h2a2 2 0 012 2v10a2 2 0 01-2 2h-2a2 2 0 01-2-2m0 0V7a2 2 0 00-2-2H9a2 2 0 00-2 2v10a2 2 0 002 2h2a2 2 0 002-2z"/>
            </svg>
            Routers
        </a>
    @endif

    <!-- Monitoring -->
    @if (auth()->user()->hasPermission('interfaces.view'))
        <a href="#"
           class="flex items-center px-4 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"/>
            </svg>
            Monitoring
        </a>
    @endif

    <!-- Firewall -->
    @if (auth()->user()->hasPermission('firewall.view'))
        <a href="#"
           class="flex items-center px-4 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4"/>
            </svg>
            Firewall
        </a>
    @endif

    <!-- Queue Management -->
    @if (auth()->user()->hasPermission('queue.view'))
        <a href="#"
           class="flex items-center px-4 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 8h14M5 8a2 2 0 110-4h14a2 2 0 110 4M5 8v10a2 2 0 002 2h10a2 2 0 002-2V8m-9 4h4"/>
            </svg>
            Queue Management
        </a>
    @endif

    <!-- VPN -->
    @if (auth()->user()->hasPermission('vpn.view'))
        <a href="#"
           class="flex items-center px-4 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
            <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/>
            </svg>
            VPN
        </a>
    @endif

    <hr class="my-4 border-slate-200 dark:border-slate-700">

    <!-- Administration -->
    @if (auth()->user()->hasPermission('users.view'))
        <div>
            <p class="px-4 py-2 text-xs font-semibold text-slate-500 dark:text-slate-400 uppercase">Administration</p>
            
            <a href="{{ route('users.index') }}"
               class="flex items-center px-4 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
                <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 4H9m6 16H9m0-11h6m6 0a9 9 0 11-18 0 9 9 0 0118 0z"/>
                </svg>
                Users
            </a>

            <a href="{{ route('audit-logs') }}"
               class="flex items-center px-4 py-2 rounded-lg text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
                <svg class="w-5 h-5 mr-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/>
                </svg>
                Audit Logs
            </a>
        </div>
    @endif

    <hr class="my-4 border-slate-200 dark:border-slate-700">

    <!-- System Info -->
    <div class="text-xs text-slate-500 dark:text-slate-400 px-4 py-2">
        <p>Logged in as: <strong>{{ auth()->user()->name }}</strong></p>
        <p>Role: <strong>{{ auth()->user()->roles->first()->display_name ?? 'N/A' }}</strong></p>
    </div>
</nav>
