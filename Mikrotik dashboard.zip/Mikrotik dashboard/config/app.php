<?php

return [
    'app' => [
        'name' => 'MikroTik Dashboard',
        'url' => env('APP_URL', 'http://localhost'),
        'timezone' => env('APP_TIMEZONE', 'UTC'),
    ],

    'database' => [
        'default' => env('DB_CONNECTION', 'mysql'),
        'connections' => [
            'mysql' => [
                'driver' => 'mysql',
                'host' => env('DB_HOST', '127.0.0.1'),
                'port' => env('DB_PORT', 3306),
                'database' => env('DB_DATABASE', 'mikrotik_dashboard'),
                'username' => env('DB_USERNAME', 'root'),
                'password' => env('DB_PASSWORD', ''),
                'charset' => 'utf8mb4',
                'collation' => 'utf8mb4_unicode_ci',
                'prefix' => '',
                'strict' => true,
                'engine' => null,
            ],
        ],
    ],

    'mikrotik' => [
        'api_timeout' => env('MIKROTIK_API_TIMEOUT', 30),
        'verify_ssl' => env('MIKROTIK_VERIFY_SSL', false),
        'pool_size' => env('MIKROTIK_POOL_SIZE', 10),
        'max_retries' => 3,
        'retry_delay' => 1000,
    ],

    'queue' => [
        'default' => env('QUEUE_CONNECTION', 'redis'),
        'connections' => [
            'redis' => [
                'driver' => 'redis',
                'connection' => 'default',
                'queue' => 'default',
                'retry_after' => 90,
                'block_for' => null,
            ],
        ],
    ],

    'cache' => [
        'default' => env('CACHE_DRIVER', 'redis'),
        'stores' => [
            'redis' => [
                'driver' => 'redis',
                'connection' => 'default',
            ],
        ],
    ],

    'auth' => [
        'guards' => [
            'web' => [
                'driver' => 'session',
                'provider' => 'users',
            ],
        ],
        'providers' => [
            'users' => [
                'driver' => 'eloquent',
                'model' => 'App\\Models\\User',
            ],
        ],
    ],

    'dashboard' => [
        'refresh_interval' => 300000, // 5 minutes in ms
        'sync_interval' => 900000, // 15 minutes in ms
        'graph_points' => 288, // 24 hours at 5-minute intervals
    ],
];
