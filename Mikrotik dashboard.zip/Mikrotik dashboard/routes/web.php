<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RouterController;
use App\Http\Controllers\InterfaceController;
use App\Http\Controllers\FirewallController;
use App\Http\Controllers\QueueController;
use App\Http\Controllers\VpnController;
use App\Http\Controllers\WirelessController;
use App\Http\Controllers\UserController;

Route::middleware('auth')->group(function () {
    
    // Dashboard
    Route::get('/', [RouterController::class, 'dashboard'])->name('dashboard');

    // Routers
    Route::prefix('routers')->group(function () {
        Route::get('/', [RouterController::class, 'index'])->name('routers.index');
        Route::get('/create', [RouterController::class, 'create'])->name('routers.create');
        Route::post('/', [RouterController::class, 'store'])->name('routers.store');
        Route::get('/{router}', [RouterController::class, 'show'])->name('routers.show');
        Route::get('/{router}/edit', [RouterController::class, 'edit'])->name('routers.edit');
        Route::put('/{router}', [RouterController::class, 'update'])->name('routers.update');
        Route::delete('/{router}', [RouterController::class, 'destroy'])->name('routers.destroy');
        Route::post('/{router}/sync', [RouterController::class, 'sync'])->name('routers.sync');
        Route::get('/{router}/check-connection', [RouterController::class, 'checkConnection'])->name('routers.check-connection');
    });

    // Interfaces
    Route::prefix('routers/{router}/interfaces')->group(function () {
        Route::get('/', [InterfaceController::class, 'index'])->name('interfaces.index');
        Route::get('/{interface}', [InterfaceController::class, 'show'])->name('interfaces.show');
        Route::post('/{interface}/toggle', [InterfaceController::class, 'toggle'])->name('interfaces.toggle');
        Route::get('/{interface}/stats', [InterfaceController::class, 'getStats'])->name('interfaces.stats');
    });

    // Firewall
    Route::prefix('routers/{router}/firewall')->group(function () {
        Route::get('/filters', [FirewallController::class, 'filters'])->name('routers.firewall.filters');
        Route::get('/nats', [FirewallController::class, 'nats'])->name('routers.firewall.nats');
        Route::get('/create-filter', [FirewallController::class, 'createFilter'])->name('firewall.create-filter');
        Route::post('/store-filter', [FirewallController::class, 'storeFilter'])->name('firewall.store-filter');
        Route::delete('/filter/{filter}', [FirewallController::class, 'deleteFilter'])->name('firewall.delete-filter');
    });

    // Queue Management
    Route::prefix('routers/{router}/queue')->group(function () {
        Route::get('/', [QueueController::class, 'index'])->name('routers.queue.index');
        Route::get('/create', [QueueController::class, 'create'])->name('routers.queue.create');
        Route::post('/', [QueueController::class, 'store'])->name('routers.queue.store');
        Route::delete('/{queue}', [QueueController::class, 'destroy'])->name('routers.queue.destroy');
    });

    // VPN Management
    Route::prefix('routers/{router}/vpn')->group(function () {
        Route::get('/sessions', [VpnController::class, 'sessions'])->name('routers.vpn.sessions');
        Route::get('/secrets', [VpnController::class, 'secrets'])->name('routers.vpn.secrets');
        Route::get('/create-secret', [VpnController::class, 'createSecret'])->name('routers.vpn.create-secret');
        Route::post('/store-secret', [VpnController::class, 'storeSecret'])->name('routers.vpn.store-secret');
    });

    // Wireless Management
    Route::prefix('routers/{router}/wireless')->group(function () {
        Route::get('/', [WirelessController::class, 'interfaces'])->name('routers.wireless.interfaces');
        Route::get('/{wireless}', [WirelessController::class, 'show'])->name('routers.wireless.show');
    });

    // User Management
    Route::prefix('users')->group(function () {
        Route::get('/', [UserController::class, 'index'])->name('users.index');
        Route::get('/create', [UserController::class, 'create'])->name('users.create');
        Route::post('/', [UserController::class, 'store'])->name('users.store');
        Route::get('/{user}', [UserController::class, 'show'])->name('users.show');
        Route::get('/{user}/edit', [UserController::class, 'edit'])->name('users.edit');
        Route::put('/{user}', [UserController::class, 'update'])->name('users.update');
        Route::delete('/{user}', [UserController::class, 'destroy'])->name('users.destroy');
    });

    // Audit Logs
    Route::get('/audit-logs', [UserController::class, 'auditLogs'])->name('audit-logs');

    // Profile
    Route::get('/profile', [UserController::class, 'show'])->name('profile.show'); // Assuming edit handles this

    // Password Change
    Route::post('/change-password', [UserController::class, 'changePassword'])->name('password.change');
});

// Authentication Routes (if using Breeze)
require __DIR__ . '/auth.php';
