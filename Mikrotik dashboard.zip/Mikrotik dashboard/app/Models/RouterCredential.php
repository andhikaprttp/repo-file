<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class RouterCredential extends Model
{
    protected $fillable = [
        'router_id',
        'username',
        'password',
        'use_ssl',
        'private_key',
    ];

    public $timestamps = true;

    // Relationships
    public function router()
    {
        return $this->belongsTo(Router::class);
    }

    // Accessors & Mutators
    public function getPasswordAttribute($value)
    {
        return $value ? Crypt::decrypt($value) : null;
    }

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = $value ? Crypt::encrypt($value) : null;
    }

    public function getPrivateKeyAttribute($value)
    {
        return $value ? Crypt::decrypt($value) : null;
    }

    public function setPrivateKeyAttribute($value)
    {
        $this->attributes['private_key'] = $value ? Crypt::encrypt($value) : null;
    }
}
