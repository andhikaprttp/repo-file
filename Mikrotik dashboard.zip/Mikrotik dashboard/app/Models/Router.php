<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Router extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'name',
        'host_ip',
        'port',
        'identity',
        'version',
        'is_active',
        'last_connection_at',
        'last_sync_at',
        'status',
        'notes',
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'last_connection_at' => 'datetime',
        'last_sync_at' => 'datetime',
    ];

    // Relationships
    public function credentials()
    {
        return $this->hasOne(RouterCredential::class);
    }

    public function interfaces()
    {
        return $this->hasMany(Interface::class);
    }

    public function dhcpLeases()
    {
        return $this->hasMany(DhcpLease::class);
    }

    public function staticRoutes()
    {
        return $this->hasMany(StaticRoute::class);
    }

    public function firewallFilters()
    {
        return $this->hasMany(FirewallFilter::class);
    }

    public function firewallNats()
    {
        return $this->hasMany(FirewallNat::class);
    }

    public function firewallMangles()
    {
        return $this->hasMany(FirewallMangle::class);
    }

    public function simpleQueues()
    {
        return $this->hasMany(SimpleQueue::class);
    }

    public function queueTrees()
    {
        return $this->hasMany(QueueTree::class);
    }

    public function pppSecrets()
    {
        return $this->hasMany(PppSecret::class);
    }

    public function pppSessions()
    {
        return $this->hasMany(PppSession::class);
    }

    public function systemStats()
    {
        return $this->hasMany(SystemStat::class);
    }

    public function activityLogs()
    {
        return $this->hasMany(ActivityLog::class);
    }

    // Methods
    public function isOnline(): bool
    {
        return $this->status === 'online';
    }

    public function isOffline(): bool
    {
        return $this->status === 'offline';
    }

    public function hasError(): bool
    {
        return $this->status === 'error';
    }

    public function getActiveInterfacesCount(): int
    {
        return $this->interfaces()->where('enabled', true)->count();
    }

    public function getLastSystemStats()
    {
        return $this->systemStats()->latest('recorded_at')->first();
    }
}
