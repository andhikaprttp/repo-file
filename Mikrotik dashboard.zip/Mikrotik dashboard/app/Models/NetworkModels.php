<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DhcpLease extends Model
{
    protected $fillable = [
        'router_id',
        'address',
        'mac_address',
        'client_id',
        'host_name',
        'expires_at',
        'status',
        'disabled',
    ];

    protected $casts = [
        'expires_at' => 'datetime',
        'disabled' => 'boolean',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }

    public function isExpired(): bool
    {
        return $this->status === 'expired' || ($this->expires_at && $this->expires_at->isPast());
    }
}

class IpAddress extends Model
{
    protected $fillable = [
        'interface_id',
        'address',
        'gateway',
        'dns',
        'network',
        'disabled',
        'comment',
    ];

    protected $casts = [
        'disabled' => 'boolean',
    ];

    public function interface()
    {
        return $this->belongsTo(Interface::class);
    }
}

class StaticRoute extends Model
{
    protected $fillable = [
        'router_id',
        'destination',
        'gateway',
        'distance',
        'disabled',
        'comment',
    ];

    protected $casts = [
        'disabled' => 'boolean',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }
}

class InterfaceStat extends Model
{
    protected $fillable = [
        'interface_id',
        'rx_bytes',
        'tx_bytes',
        'rx_packets',
        'tx_packets',
        'rx_errors',
        'tx_errors',
        'rx_rate',
        'tx_rate',
        'recorded_at',
    ];

    protected $casts = [
        'recorded_at' => 'datetime',
    ];

    public function interface()
    {
        return $this->belongsTo(Interface::class);
    }

    public function getTotalBytesTransferred(): int
    {
        return $this->rx_bytes + $this->tx_bytes;
    }
}

class SystemStat extends Model
{
    protected $fillable = [
        'router_id',
        'cpu_usage',
        'memory_usage',
        'memory_total',
        'memory_free',
        'uptime',
        'temperature',
        'recorded_at',
    ];

    protected $casts = [
        'recorded_at' => 'datetime',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }

    public function getFormattedUptime(): string
    {
        $seconds = $this->uptime;
        $days = floor($seconds / 86400);
        $hours = floor(($seconds % 86400) / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        
        return "{$days}d {$hours}h {$minutes}m";
    }
}
