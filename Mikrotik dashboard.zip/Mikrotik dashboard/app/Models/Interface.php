<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Interface extends Model
{
    protected $table = 'interfaces';

    protected $fillable = [
        'router_id',
        'name',
        'type',
        'enabled',
        'mac_address',
        'mtu',
        'comment',
        'metadata',
    ];

    protected $casts = [
        'enabled' => 'boolean',
        'metadata' => 'array',
    ];

    // Relationships
    public function router()
    {
        return $this->belongsTo(Router::class);
    }

    public function ipAddresses()
    {
        return $this->hasMany(IpAddress::class);
    }

    public function stats()
    {
        return $this->hasMany(InterfaceStat::class);
    }

    public function wirelessInterface()
    {
        return $this->hasOne(WirelessInterface::class);
    }

    // Methods
    public function getLatestStats()
    {
        return $this->stats()->latest('recorded_at')->first();
    }

    public function isWireless(): bool
    {
        return in_array($this->type, ['wifi', 'wireless', 'wifiwave2']);
    }

    public function isPpp(): bool
    {
        return in_array($this->type, ['ppp', 'pptp', 'l2tp', 'ovpn']);
    }

    public function getStatusBadgeColor(): string
    {
        return $this->enabled ? 'success' : 'secondary';
    }
}
