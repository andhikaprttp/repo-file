<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FirewallFilter extends Model
{
    protected $fillable = [
        'router_id',
        'chain_position',
        'chain',
        'in_interface',
        'out_interface',
        'src_address',
        'dst_address',
        'src_port',
        'dst_port',
        'protocol',
        'connection_state',
        'action',
        'disabled',
        'comment',
    ];

    protected $casts = [
        'disabled' => 'boolean',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }
}

class FirewallNat extends Model
{
    protected $fillable = [
        'router_id',
        'chain_position',
        'chain',
        'in_interface',
        'out_interface',
        'src_address',
        'dst_address',
        'action',
        'to_addresses',
        'to_ports',
        'disabled',
        'comment',
    ];

    protected $casts = [
        'disabled' => 'boolean',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }
}

class FirewallMangle extends Model
{
    protected $fillable = [
        'router_id',
        'chain_position',
        'chain',
        'in_interface',
        'out_interface',
        'action',
        'new_mark',
        'disabled',
        'comment',
    ];

    protected $casts = [
        'disabled' => 'boolean',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }
}

class SimpleQueue extends Model
{
    protected $fillable = [
        'router_id',
        'name',
        'target',
        'direction',
        'limit_tx',
        'limit_rx',
        'burst_limit_tx',
        'burst_limit_rx',
        'disabled',
        'comment',
    ];

    protected $casts = [
        'disabled' => 'boolean',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }

    public function getLimitMbpsAttribute()
    {
        return $this->limit_tx ? round($this->limit_tx / 1000 / 1000, 2) : null;
    }
}

class QueueTree extends Model
{
    protected $fillable = [
        'router_id',
        'parent',
        'name',
        'packet_mark',
        'priority',
        'limit_at',
        'max_limit',
        'burst_limit',
        'burst_time',
        'disabled',
    ];

    protected $casts = [
        'disabled' => 'boolean',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }
}

class ActivityLog extends Model
{
    protected $fillable = [
        'user_id',
        'router_id',
        'action',
        'entity_type',
        'entity_id',
        'changes',
        'ip_address',
        'user_agent',
    ];

    protected $casts = [
        'changes' => 'array',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function router()
    {
        return $this->belongsTo(Router::class);
    }
}

class AuditLog extends Model
{
    protected $fillable = [
        'user_id',
        'event_type',
        'description',
        'ip_address',
        'user_agent',
        'status',
        'details',
    ];

    protected $casts = [
        'details' => 'array',
    ];

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function isSuccess(): bool
    {
        return $this->status === 'success';
    }
}
