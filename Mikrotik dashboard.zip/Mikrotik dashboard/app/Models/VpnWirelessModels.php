<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Crypt;

class PppSecret extends Model
{
    protected $fillable = [
        'router_id',
        'name',
        'service',
        'password',
        'local_address',
        'remote_address',
        'disabled',
        'comment',
    ];

    protected $casts = [
        'disabled' => 'boolean',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }

    public function getPasswordAttribute($value)
    {
        return $value ? Crypt::decrypt($value) : null;
    }

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = $value ? Crypt::encrypt($value) : null;
    }

    public function getServiceLabel(): string
    {
        return match ($this->service) {
            'pppoe' => 'PPPoE',
            'pptp' => 'PPTP',
            'l2tp' => 'L2TP',
            'ovpn' => 'OpenVPN',
            default => ucfirst($this->service),
        };
    }
}

class PppSession extends Model
{
    protected $fillable = [
        'router_id',
        'name',
        'service',
        'remote_address',
        'local_address',
        'uptime',
        'tx_bytes',
        'rx_bytes',
        'connected_at',
    ];

    protected $casts = [
        'connected_at' => 'datetime',
    ];

    public function router()
    {
        return $this->belongsTo(Router::class);
    }

    public function getFormattedUptime(): string
    {
        $seconds = $this->uptime;
        $days = floor($seconds / 86400);
        $hours = floor(($seconds % 86400) / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        
        return "{$days}d {$hours}h {$minutes}m";
    }

    public function getTransferedTraffic(): string
    {
        $total = $this->tx_bytes + $this->rx_bytes;
        if ($total > 1073741824) {
            return round($total / 1073741824, 2) . ' GB';
        } elseif ($total > 1048576) {
            return round($total / 1048576, 2) . ' MB';
        }
        return round($total / 1024, 2) . ' KB';
    }
}

class WirelessInterface extends Model
{
    protected $fillable = [
        'interface_id',
        'ssid',
        'mode',
        'band',
        'channel',
        'tx_power',
        'antenna_gain',
        'security_profile',
        'client_count',
    ];

    protected $casts = [
        'client_count' => 'integer',
    ];

    public function interface()
    {
        return $this->belongsTo(Interface::class);
    }

    public function clients()
    {
        return $this->hasMany(WirelessClient::class);
    }

    public function geteModeLabel(): string
    {
        return match ($this->mode) {
            'ap-bridge' => 'Access Point',
            'station' => 'Station',
            'bridge' => 'Bridge',
            'monitor' => 'Monitor',
            default => ucfirst($this->mode),
        };
    }

    public function getBandLabel(): string
    {
        return match ($this->band) {
            '2ghz-b' => '2.4 GHz (802.11b)',
            '2ghz-g' => '2.4 GHz (802.11g)',
            '2ghz-n' => '2.4 GHz (802.11n)',
            '5ghz' => '5 GHz (802.11a/n/ac)',
            '6ghz' => '6 GHz (802.11ax)',
            default => $this->band,
        };
    }
}

class WirelessClient extends Model
{
    protected $fillable = [
        'wireless_interface_id',
        'mac_address',
        'interface',
        'signal_strength',
        'signal_to_noise_ratio',
        'rx_rate',
        'tx_rate',
        'rx_bytes',
        'tx_bytes',
        'connected_at',
    ];

    protected $casts = [
        'connected_at' => 'datetime',
    ];

    public function wirelessInterface()
    {
        return $this->belongsTo(WirelessInterface::class);
    }

    public function getSignalStrengthColor(): string
    {
        $signal = $this->signal_strength;
        if ($signal >= -50) return 'success';
        if ($signal >= -70) return 'info';
        if ($signal >= -85) return 'warning';
        return 'danger';
    }

    public function getSignalStrengthPercentage(): int
    {
        // Convert dBm to percentage (roughly)
        $signal = $this->signal_strength ?? -100;
        return max(0, min(100, 2 * ($signal + 100)));
    }
}
