<?php

namespace App\Http\Controllers;

use App\Models\Router;
use App\Services\MikroTikService;
use App\Services\RouterSyncService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use App\Http\Requests\StoreRouterRequest;
use App\Http\Requests\UpdateRouterRequest;

class RouterController extends Controller
{
    /**
     * Display dashboard overview
     */
    public function dashboard()
    {
        $routers = Router::where('is_active', true)->get();
        
        $onlineCount = $routers->where('status', 'online')->count();
        $offlineCount = $routers->where('status', 'offline')->count();
        $errorCount = $routers->where('status', 'error')->count();

        return view('dashboard', [
            'routers' => $routers,
            'onlineCount' => $onlineCount,
            'offlineCount' => $offlineCount,
            'errorCount' => $errorCount,
            'totalInterfaces' => $this->getTotalInterfaces($routers),
            'totalDevices' => $this->getTotalDevices($routers),
        ]);
    }

    /**
     * Display list of routers
     */
    public function index()
    {
        $routers = Router::with(['credentials'])
            ->where('is_active', true)
            ->paginate(15);

        return view('routers.index', compact('routers'));
    }

    /**
     * Show router detail
     */
    public function show(Router $router)
    {
        $router->load([
            'credentials',
            'interfaces' => function ($query) {
                $query->with('stats', 'ipAddresses');
            },
            'systemStats' => function ($query) {
                $query->latest('recorded_at')->limit(288); // 24 hours at 5-minute intervals
            },
            'dhcpLeases',
            'staticRoutes',
        ]);

        return view('routers.show', compact('router'));
    }

    /**
     * Show create router form
     */
    public function create()
    {
        return view('routers.create');
    }

    /**
     * Store router
     */
    public function store(StoreRouterRequest $request)
    {
        $router = Router::create($request->validated());

        // Create credentials
        if ($request->filled(['username', 'password'])) {
            $router->credentials()->create([
                'username' => $request->username,
                'password' => $request->password,
                'use_ssl' => $request->boolean('use_ssl', false),
            ]);
        }

        // Test connection
        $service = new MikroTikService($router);
        if ($service->connect()) {
            $info = $service->getSystemInfo();
            $router->update([
                'identity' => $info['identity'] ?? null,
                'version' => $info['version'] ?? null,
                'status' => 'online',
            ]);
        } else {
            $router->update(['status' => 'offline']);
        }
        $service->disconnect();

        // Log activity
        activity('router_added')
            ->performedBy(auth()->user())
            ->on($router)
            ->withProperties(['name' => $router->name])
            ->log();

        return redirect()->route('routers.show', $router)
            ->with('success', 'Router added successfully');
    }

    /**
     * Show edit router form
     */
    public function edit(Router $router)
    {
        return view('routers.edit', compact('router'));
    }

    /**
     * Update router
     */
    public function update(UpdateRouterRequest $request, Router $router)
    {
        $changes = [];

        // Track changes for audit log
        foreach ($request->validated() as $key => $value) {
            if ($router->$key !== $value) {
                $changes[$key] = [
                    'from' => $router->$key,
                    'to' => $value,
                ];
            }
        }

        $router->update($request->validated());

        // Update credentials if provided
        if ($request->filled(['username', 'password'])) {
            $router->credentials()->updateOrCreate([], [
                'username' => $request->username,
                'password' => $request->password,
                'use_ssl' => $request->boolean('use_ssl', false),
            ]);
        }

        // Log activity
        activity('router_updated')
            ->performedBy(auth()->user())
            ->on($router)
            ->withProperties($changes)
            ->log();

        return redirect()->route('routers.show', $router)
            ->with('success', 'Router updated successfully');
    }

    /**
     * Delete router
     */
    public function destroy(Router $router)
    {
        $name = $router->name;
        
        $router->delete();

        activity('router_deleted')
            ->performedBy(auth()->user())
            ->withProperties(['name' => $name])
            ->log();

        return redirect()->route('routers.index')
            ->with('success', 'Router deleted successfully');
    }

    /**
     * Sync router data from API
     */
    public function sync(Router $router)
    {
        $sync = new RouterSyncService($router);
        
        if ($sync->syncAll()) {
            return redirect()->back()
                ->with('success', 'Router synced successfully');
        }

        return redirect()->back()
            ->with('error', 'Failed to sync router. Check router connection.');
    }

    /**
     * Check connection status
     */
    public function checkConnection(Router $router)
    {
        $service = new MikroTikService($router);
        
        $connected = $service->connect();
        
        if ($connected) {
            $info = $service->getSystemInfo();
            $resources = $service->getSystemResources();

            return response()->json([
                'status' => 'online',
                'identity' => $info['identity'] ?? 'Unknown',
                'version' => $info['version'] ?? 'Unknown',
                'cpu' => $resources['cpu_usage'] ?? 0,
                'memory' => $resources['memory_usage'] ?? 0,
            ]);
        }

        return response()->json([
            'status' => 'offline',
            'message' => 'Cannot connect to router',
        ], 503);
    }

    /**
     * Get helper metrics
     */
    protected function getTotalInterfaces($routers)
    {
        return $routers->sum(function ($router) {
            return $router->interfaces()->count();
        });
    }

    protected function getTotalDevices($routers)
    {
        return $routers->sum(function ($router) {
            return $router->dhcpLeases()->where('status', 'active')->count();
        });
    }
}
