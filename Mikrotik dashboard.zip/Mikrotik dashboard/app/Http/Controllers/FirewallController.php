<?php

namespace App\Http\Controllers;

use App\Models\Router;
use App\Models\FirewallFilter;
use App\Models\FirewallNat;
use App\Models\SimpleQueue;
use App\Services\MikroTikService;
use Illuminate\Http\Request;

class FirewallController extends Controller
{
    /**
     * List firewall filters
     */
    public function filters(Router $router)
    {
        $filters = $router->firewallFilters()
            ->orderBy('chain_position')
            ->paginate(20);

        return view('firewall.filters', [
            'router' => $router,
            'filters' => $filters,
        ]);
    }

    /**
     * List firewall NAT rules
     */
    public function nats(Router $router)
    {
        $nats = $router->firewallNats()
            ->orderBy('chain_position')
            ->paginate(20);

        return view('firewall.nats', [
            'router' => $router,
            'nats' => $nats,
        ]);
    }

    /**
     * Show add filter form
     */
    public function createFilter(Router $router)
    {
        return view('firewall.create-filter', [
            'router' => $router,
        ]);
    }

    /**
     * Add firewall filter
     */
    public function storeFilter(Request $request, Router $router)
    {
        $data = $request->validate([
            'chain' => 'required|in:input,output,forward',
            'in_interface' => 'nullable|string',
            'out_interface' => 'nullable|string',
            'src_address' => 'nullable|string',
            'dst_address' => 'nullable|string',
            'protocol' => 'nullable|string',
            'action' => 'required|in:accept,drop,log',
            'disabled' => 'nullable|boolean',
            'comment' => 'nullable|string',
        ]);

        $service = new MikroTikService($router);

        if (!$service->connect()) {
            return back()->with('error', 'Cannot connect to router');
        }

        $apiData = $this->buildFirewallFilterData($data);

        try {
            $id = $service->add('/ip/firewall/filter', $apiData);

            // Save to DB
            $data['router_id'] = $router->id;
            FirewallFilter::create($data);

            activity('firewall_filter_added')
                ->performedBy(auth()->user())
                ->on($router)
                ->withProperties($data)
                ->log();

            return redirect()->route('routers.firewall.filters', $router)
                ->with('success', 'Filter added successfully');

        } catch (\Exception $e) {
            return back()->with('error', 'Failed to add filter: ' . $e->getMessage());
        }
    }

    /**
     * Delete firewall filter
     */
    public function deleteFilter(Router $router, FirewallFilter $filter)
    {
        $service = new MikroTikService($router);

        if (!$service->connect()) {
            return back()->with('error', 'Cannot connect to router');
        }

        // The .id from API might be different from DB id
        // This would need to be enhanced for production

        try {
            $filter->delete();

            activity('firewall_filter_deleted')
                ->performedBy(auth()->user())
                ->on($router)
                ->withProperties(['comment' => $filter->comment])
                ->log();

            return redirect()->back()
                ->with('success', 'Filter deleted successfully');

        } catch (\Exception $e) {
            return back()->with('error', 'Failed to delete filter: ' . $e->getMessage());
        }
    }

    /**
     * Build API data structure for firewall filter
     */
    protected function buildFirewallFilterData($data)
    {
        return array_filter([
            'chain' => $data['chain'],
            'in-interface' => $data['in_interface'],
            'out-interface' => $data['out_interface'],
            'src-address' => $data['src_address'],
            'dst-address' => $data['dst_address'],
            'protocol' => $data['protocol'],
            'action' => $data['action'],
            'disabled' => (bool) ($data['disabled'] ?? false),
            'comment' => $data['comment'],
        ]);
    }
}
