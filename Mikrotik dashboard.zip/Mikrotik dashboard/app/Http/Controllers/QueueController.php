<?php

namespace App\Http\Controllers;

use App\Models\Router;
use App\Models\SimpleQueue;
use App\Models\PppSession;
use App\Models\WirelessInterface;
use App\Services\MikroTikService;
use Illuminate\Http\Request;

class QueueController extends Controller
{
    /**
     * List simple queues
     */
    public function index(Router $router)
    {
        $queues = $router->simpleQueues()->paginate(20);

        return view('queue.index', [
            'router' => $router,
            'queues' => $queues,
        ]);
    }

    /**
     * Create queue form
     */
    public function create(Router $router)
    {
        return view('queue.create', ['router' => $router]);
    }

    /**
     * Store queue
     */
    public function store(Request $request, Router $router)
    {
        $data = $request->validate([
            'name' => 'required|string|unique:simple_queues',
            'target' => 'required|string',
            'direction' => 'required|in:up,down,both',
            'limit_tx' => 'nullable|integer|min:1',
            'limit_rx' => 'nullable|integer|min:1',
            'disabled' => 'nullable|boolean',
            'comment' => 'nullable|string',
        ]);

        $service = new MikroTikService($router);

        if (!$service->connect()) {
            return back()->with('error', 'Cannot connect to router');
        }

        try {
            $apiData = [
                'name' => $data['name'],
                'target' => $data['target'],
                'direction' => $data['direction'],
            ];

            if ($data['limit_tx'] ?? null) {
                $apiData['max-limit'] = "{$data['limit_tx']}/0";
            }

            if ($data['limit_rx'] ?? null) {
                $apiData['max-limit'] = "0/{$data['limit_rx']}";
            }

            $service->add('/queue/simple', $apiData);

            $data['router_id'] = $router->id;
            SimpleQueue::create($data);

            activity('queue_added')
                ->performedBy(auth()->user())
                ->on($router)
                ->withProperties(['name' => $data['name']])
                ->log();

            return redirect()->route('routers.queue.index', $router)
                ->with('success', 'Queue added successfully');

        } catch (\Exception $e) {
            return back()->with('error', 'Failed to add queue: ' . $e->getMessage());
        }
    }

    /**
     * Delete queue
     */
    public function destroy(Router $router, SimpleQueue $queue)
    {
        $queue->delete();

        activity('queue_deleted')
            ->performedBy(auth()->user())
            ->on($router)
            ->withProperties(['name' => $queue->name])
            ->log();

        return redirect()->back()->with('success', 'Queue deleted');
    }
}

class VpnController extends Controller
{
    /**
     * List PPP sessions
     */
    public function sessions(Router $router)
    {
        $sessions = $router->pppSessions()
            ->latest('connected_at')
            ->paginate(20);

        return view('vpn.sessions', [
            'router' => $router,
            'sessions' => $sessions,
        ]);
    }

    /**
     * List PPP secrets
     */
    public function secrets(Router $router)
    {
        if (!auth()->user()->hasPermission('vpn.view_secrets')) {
            abort(403, 'Unauthorized');
        }

        $secrets = $router->pppSecrets()->paginate(20);

        return view('vpn.secrets', [
            'router' => $router,
            'secrets' => $secrets,
        ]);
    }

    /**
     * Add PPP secret
     */
    public function createSecret(Router $router)
    {
        return view('vpn.create-secret', ['router' => $router]);
    }

    /**
     * Store PPP secret
     */
    public function storeSecret(Request $request, Router $router)
    {
        if (!auth()->user()->hasPermission('vpn.create_secret')) {
            abort(403, 'Unauthorized');
        }

        $data = $request->validate([
            'name' => 'required|string|unique:ppp_secrets',
            'service' => 'required|in:pppoe,pptp,l2tp,ovpn',
            'password' => 'required|string|min:8',
            'local_address' => 'nullable|ip',
            'remote_address' => 'nullable|ip',
            'comment' => 'nullable|string',
        ]);

        $service = new MikroTikService($router);

        if (!$service->connect()) {
            return back()->with('error', 'Cannot connect to router');
        }

        try {
            $apiData = [
                'name' => $data['name'],
                'service' => $data['service'],
                'password' => $data['password'],
            ];

            if ($data['local_address'] ?? null) {
                $apiData['local-address'] = $data['local_address'];
            }

            if ($data['remote_address'] ?? null) {
                $apiData['remote-address'] = $data['remote_address'];
            }

            $service->add('/ppp/secret', $apiData);

            $data['router_id'] = $router->id;
            \App\Models\PppSecret::create($data);

            activity('vpn_secret_created')
                ->performedBy(auth()->user())
                ->on($router)
                ->withProperties(['name' => $data['name']])
                ->log();

            return redirect()->route('routers.vpn.secrets', $router)
                ->with('success', 'VPN secret created successfully');

        } catch (\Exception $e) {
            return back()->with('error', 'Failed to create VPN secret: ' . $e->getMessage());
        }
    }
}

class WirelessController extends Controller
{
    /**
     * List wireless interfaces with clients
     */
    public function interfaces(Router $router)
    {
        $interfaces = $router->interfaces()
            ->where('type', 'like', '%wifi%')
            ->with(['wirelessInterface.clients'])
            ->paginate(10);

        return view('wireless.interfaces', [
            'router' => $router,
            'interfaces' => $interfaces,
        ]);
    }

    /**
     * Show wireless interface details
     */
    public function show(Router $router, WirelessInterface $wireless)
    {
        $wireless->load(['interface', 'clients' => function ($query) {
            $query->latest('updated_at');
        }]);

        return view('wireless.show', [
            'router' => $router,
            'wireless' => $wireless,
        ]);
    }
}
