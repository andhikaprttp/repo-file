<?php

namespace App\Http\Controllers;

use App\Models\Router;
use App\Models\Interface;
use App\Services\MikroTikService;
use Illuminate\Http\Request;

class InterfaceController extends Controller
{
    /**
     * List interfaces for router
     */
    public function index(Router $router)
    {
        $interfaces = $router->interfaces()
            ->with(['stats' => function ($query) {
                $query->latest('recorded_at')->first();
            }, 'ipAddresses'])
            ->paginate(20);

        return view('interfaces.index', [
            'router' => $router,
            'interfaces' => $interfaces,
        ]);
    }

    /**
     * Show interface details
     */
    public function show(Router $router, Interface $interface)
    {
        $interface->load([
            'ipAddresses',
            'stats' => function ($query) {
                $query->latest('recorded_at')->limit(288);
            },
            'wirelessInterface',
        ]);

        if ($interface->isWireless() && $interface->wirelessInterface) {
            $interface->wirelessInterface->load(['clients']);
        }

        return view('interfaces.show', [
            'router' => $router,
            'interface' => $interface,
        ]);
    }

    /**
     * Toggle interface state
     */
    public function toggle(Router $router, Interface $interface)
    {
        $service = new MikroTikService($router);

        if (!$service->connect()) {
            return response()->json([
                'success' => false,
                'message' => 'Cannot connect to router',
            ], 503);
        }

        $newState = !$interface->enabled;

        // Find the interface ID from API
        $apiInterfaces = $service->getInterfaces();
        $apiInterface = collect($apiInterfaces)
            ->firstWhere('name', $interface->name);

        if (!$apiInterface) {
            return response()->json([
                'success' => false,
                'message' => 'Interface not found on router',
            ], 404);
        }

        if ($service->setInterfaceState($apiInterface['.id'], $newState)) {
            $interface->update(['enabled' => $newState]);

            activity('interface_toggled')
                ->performedBy(auth()->user())
                ->on($router)
                ->withProperties([
                    'interface' => $interface->name,
                    'state' => $newState ? 'enabled' : 'disabled',
                ])
                ->log();

            return response()->json([
                'success' => true,
                'message' => 'Interface ' . ($newState ? 'enabled' : 'disabled'),
                'state' => $newState,
            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'Failed to update interface',
        ], 500);
    }

    /**
     * Get real-time traffic stats (AJAX)
     */
    public function getStats(Router $router, Interface $interface)
    {
        $latestStat = $interface->stats()->latest('recorded_at')->first();

        if (!$latestStat) {
            return response()->json([
                'rx_bytes' => 0,
                'tx_bytes' => 0,
                'rx_rate' => 0,
                'tx_rate' => 0,
            ]);
        }

        // Calculate rates if we have previous stat
        $previousStat = $interface->stats()
            ->where('id', '<', $latestStat->id)
            ->latest('recorded_at')
            ->first();

        $rx_rate = 0;
        $tx_rate = 0;

        if ($previousStat) {
            $timeDiff = max(1, $latestStat->recorded_at->diffInSeconds($previousStat->recorded_at));
            $rx_rate = round(($latestStat->rx_bytes - $previousStat->rx_bytes) / $timeDiff);
            $tx_rate = round(($latestStat->tx_bytes - $previousStat->tx_bytes) / $timeDiff);
        }

        return response()->json([
            'rx_bytes' => $latestStat->rx_bytes,
            'tx_bytes' => $latestStat->tx_bytes,
            'rx_packets' => $latestStat->rx_packets,
            'tx_packets' => $latestStat->tx_packets,
            'rx_errors' => $latestStat->rx_errors,
            'tx_errors' => $latestStat->tx_errors,
            'rx_rate' => $this->formatBytes($rx_rate) . '/s',
            'tx_rate' => $this->formatBytes($tx_rate) . '/s',
            'total_bytes' => $this->formatBytes($latestStat->rx_bytes + $latestStat->tx_bytes),
        ]);
    }

    /**
     * Format bytes to human readable
     */
    protected function formatBytes($bytes)
    {
        $units = ['B', 'KB', 'MB', 'GB'];
        $bytes = max($bytes, 0);
        $pow = floor(($bytes ? log($bytes) : 0) / log(1024));
        $pow = min($pow, count($units) - 1);
        $bytes /= (1 << (10 * $pow));

        return round($bytes, 2) . ' ' . $units[$pow];
    }
}
