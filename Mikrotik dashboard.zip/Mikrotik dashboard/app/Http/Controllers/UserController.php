<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Role;
use App\Models\AuditLog;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\Rules\Password;

class UserController extends Controller
{
    /**
     * List users
     */
    public function index()
    {
        $users = User::with('roles')->paginate(20);

        return view('users.index', compact('users'));
    }

    /**
     * Show user details
     */
    public function show(User $user)
    {
        $user->load(['roles', 'activityLogs' => function ($query) {
            $query->latest()->limit(50);
        }]);

        return view('users.show', compact('user'));
    }

    /**
     * Create user form
     */
    public function create()
    {
        $roles = Role::all();

        return view('users.create', compact('roles'));
    }

    /**
     * Store user
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:users',
            'password' => ['required', Password::defaults()],
            'roles' => 'required|array|min:1',
            'roles.*' => 'exists:roles,id',
            'is_active' => 'nullable|boolean',
        ]);

        $user = User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => Hash::make($data['password']),
            'is_active' => $data['is_active'] ?? true,
        ]);

        // Assign roles
        $user->roles()->sync($data['roles']);

        activity('user_created')
            ->performedBy(auth()->user())
            ->on($user)
            ->withProperties(['email' => $user->email])
            ->log();

        AuditLog::create([
            'user_id' => auth()->id(),
            'event_type' => 'user_created',
            'description' => "Created user: {$user->email}",
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'status' => 'success',
        ]);

        return redirect()->route('users.show', $user)
            ->with('success', 'User created successfully');
    }

    /**
     * Edit user form
     */
    public function edit(User $user)
    {
        $roles = Role::all();
        $user->load('roles');

        return view('users.edit', compact('user', 'roles'));
    }

    /**
     * Update user
     */
    public function update(Request $request, User $user)
    {
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => "required|email|unique:users,email,{$user->id}",
            'password' => ['nullable', Password::defaults()],
            'roles' => 'required|array|min:1',
            'roles.*' => 'exists:roles,id',
            'is_active' => 'nullable|boolean',
        ]);

        $changes = [];

        // Track changes
        foreach (['name', 'email', 'is_active'] as $field) {
            if (isset($data[$field]) && $user->$field !== $data[$field]) {
                $changes[$field] = [
                    'from' => $user->$field,
                    'to' => $data[$field],
                ];
            }
        }

        $user->update([
            'name' => $data['name'],
            'email' => $data['email'],
            'is_active' => $data['is_active'] ?? true,
        ]);

        if ($data['password'] ?? null) {
            $user->update(['password' => Hash::make($data['password'])]);
            $changes['password'] = 'updated';
        }

        // Sync roles
        $user->roles()->sync($data['roles']);

        activity('user_updated')
            ->performedBy(auth()->user())
            ->on($user)
            ->withProperties($changes)
            ->log();

        AuditLog::create([
            'user_id' => auth()->id(),
            'event_type' => 'user_updated',
            'description' => "Updated user: {$user->email}",
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'status' => 'success',
        ]);

        return redirect()->route('users.show', $user)
            ->with('success', 'User updated successfully');
    }

    /**
     * Delete user
     */
    public function destroy(User $user)
    {
        $email = $user->email;

        // Soft delete
        $user->delete();

        activity('user_deleted')
            ->performedBy(auth()->user())
            ->withProperties(['email' => $email])
            ->log();

        AuditLog::create([
            'user_id' => auth()->id(),
            'event_type' => 'user_deleted',
            'description' => "Deleted user: {$email}",
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'status' => 'success',
        ]);

        return redirect()->route('users.index')
            ->with('success', 'User deleted successfully');
    }

    /**
     * Show audit logs
     */
    public function auditLogs()
    {
        $logs = AuditLog::latest()
            ->with('user')
            ->paginate(50);

        return view('audit-logs', compact('logs'));
    }

    /**
     * Change password
     */
    public function changePassword(Request $request)
    {
        $data = $request->validate([
            'current_password' => 'required|current_password',
            'password' => ['required', 'confirmed', Password::defaults()],
        ]);

        auth()->user()->update([
            'password' => Hash::make($data['password']),
        ]);

        AuditLog::create([
            'user_id' => auth()->id(),
            'event_type' => 'password_changed',
            'description' => 'Changed password',
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
            'status' => 'success',
        ]);

        return redirect()->back()->with('success', 'Password changed successfully');
    }
}
