<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreRouterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->user()->hasPermission('routers.create');
    }

    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255|unique:routers',
            'host_ip' => 'required|ip',
            'port' => 'nullable|integer|between:1,65535',
            'username' => 'required|string',
            'password' => 'required|string|min:8',
            'use_ssl' => 'nullable|boolean',
            'notes' => 'nullable|string|max:1000',
        ];
    }

    public function messages(): array
    {
        return [
            'name.required' => 'Router name is required',
            'name.unique' => 'Router name must be unique',
            'host_ip.required' => 'Router IP address is required',
            'host_ip.ip' => 'Please provide a valid IP address',
            'username.required' => 'API username is required',
            'password.required' => 'API password is required',
            'password.min' => 'Password must be at least 8 characters',
        ];
    }
}

class UpdateRouterRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->user()->hasPermission('routers.update');
    }

    public function rules(): array
    {
        return [
            'name' => "required|string|max:255|unique:routers,name,{$this->router->id}",
            'host_ip' => 'required|ip',
            'port' => 'nullable|integer|between:1,65535',
            'username' => 'required|string',
            'password' => 'required|string|min:8',
            'use_ssl' => 'nullable|boolean',
            'is_active' => 'nullable|boolean',
            'notes' => 'nullable|string|max:1000',
        ];
    }
}
