<?php

namespace App\Services;

use App\Models\Router;
use App\Models\Interface;
use App\Models\InterfaceStat;
use App\Models\SystemStat;
use App\Models\DhcpLease;
use Exception;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;

/**
 * Router Data Synchronization Service
 * 
 * Syncs data from MikroTik routers to the database
 */
class RouterSyncService
{
    protected $mikrotikService;
    protected $router;

    public function __construct(Router $router)
    {
        $this->router = $router;
        $this->mikrotikService = new MikroTikService($router);
    }

    /**
     * Sync all data from router
     */
    public function syncAll(): bool
    {
        try {
            if (!$this->mikrotikService->connect()) {
                return false;
            }

            $this->syncSystemInfo();
            $this->syncSystemResources();
            $this->syncInterfaces();
            $this->syncDhcpLeases();
            $this->syncPppActive();

            $this->router->update([
                'status' => 'online',
                'last_sync_at' => now(),
            ]);

            Log::info("Successfully synced router: {$this->router->name}");
            return true;

        } catch (Exception $e) {
            Log::error("Failed to sync router {$this->router->name}: {$e->getMessage()}");
            $this->router->update(['status' => 'error']);
            return false;

        } finally {
            $this->mikrotikService->disconnect();
        }
    }

    /**
     * Sync system information
     */
    protected function syncSystemInfo(): void
    {
        try {
            $info = $this->mikrotikService->getSystemInfo();

            $this->router->update([
                'identity' => $info['identity'] ?? null,
                'version' => $info['version'] ?? null,
            ]);

            Log::debug("Synced system info for {$this->router->name}");

        } catch (Exception $e) {
            Log::error("Failed to sync system info: {$e->getMessage()}");
        }
    }

    /**
     * Sync system resources
     */
    protected function syncSystemResources(): void
    {
        try {
            $resources = $this->mikrotikService->getSystemResources();

            if (!empty($resources)) {
                SystemStat::create([
                    'router_id' => $this->router->id,
                    'cpu_usage' => $resources['cpu_usage'] ?? 0,
                    'memory_usage' => $resources['memory_usage'] ?? 0,
                    'memory_total' => $resources['memory_total'] ?? 0,
                    'memory_free' => $resources['memory_free'] ?? 0,
                    'uptime' => $resources['uptime'] ?? 0,
                    'temperature' => $resources['temperature'] ?? null,
                    'recorded_at' => now(),
                ]);

                Log::debug("Synced system resources for {$this->router->name}");
            }

        } catch (Exception $e) {
            Log::error("Failed to sync system resources: {$e->getMessage()}");
        }
    }

    /**
     * Sync interfaces and statistics
     */
    protected function syncInterfaces(): void
    {
        try {
            $interfaces = $this->mikrotikService->getInterfaces();

            foreach ($interfaces as $intf) {
                $interface = Interface::updateOrCreate(
                    [
                        'router_id' => $this->router->id,
                        'name' => $intf['name'],
                    ],
                    [
                        'type' => $intf['type'] ?? 'ether',
                        'enabled' => !($intf['disabled'] ?? false),
                        'mac_address' => $intf['mac_address'] ?? null,
                        'mtu' => $intf['mtu'] ?? 1500,
                        'comment' => $intf['comment'] ?? null,
                    ]
                );

                // Sync stats
                $stats = $this->mikrotikService->getInterfaceStats($intf['name']);
                if (!empty($stats)) {
                    InterfaceStat::create([
                        'interface_id' => $interface->id,
                        'rx_bytes' => $stats['rx_bytes'],
                        'tx_bytes' => $stats['tx_bytes'],
                        'rx_packets' => $stats['rx_packets'],
                        'tx_packets' => $stats['tx_packets'],
                        'rx_errors' => $stats['rx_errors'] ?? 0,
                        'tx_errors' => $stats['tx_errors'] ?? 0,
                        'recorded_at' => now(),
                    ]);
                }
            }

            Log::debug("Synced interfaces for {$this->router->name}");

        } catch (Exception $e) {
            Log::error("Failed to sync interfaces: {$e->getMessage()}");
        }
    }

    /**
     * Sync DHCP leases
     */
    protected function syncDhcpLeases(): void
    {
        try {
            $leases = $this->mikrotikService->getDhcpLeases();

            foreach ($leases as $lease) {
                DhcpLease::updateOrCreate(
                    [
                        'router_id' => $this->router->id,
                        'address' => $lease['address'] ?? null,
                    ],
                    [
                        'mac_address' => $lease['mac-address'] ?? null,
                        'client_id' => $lease['client-id'] ?? null,
                        'host_name' => $lease['host-name'] ?? null,
                        'status' => $lease['status'] ?? 'active',
                        'disabled' => (bool) ($lease['disabled'] ?? false),
                        'expires_at' => $lease['expires-after'] ? 
                            Carbon::now()->addSeconds((int) $this->parseTime($lease['expires-after'])) : null,
                    ]
                );
            }

            Log::debug("Synced DHCP leases for {$this->router->name}");

        } catch (Exception $e) {
            Log::error("Failed to sync DHCP leases: {$e->getMessage()}");
        }
    }

    /**
     * Sync PPP Active Sessions
     */
    protected function syncPppActive(): void
    {
        try {
            $sessions = $this->mikrotikService->getPppActive();

            // Implementation for syncing PPP sessions
            // This would sync to PppSession model

            Log::debug("Synced PPP sessions for {$this->router->name}");

        } catch (Exception $e) {
            Log::error("Failed to sync PPP sessions: {$e->getMessage()}");
        }
    }

    /**
     * Parse MikroTik time format (e.g., "1d2h3m4s")
     */
    protected function parseTime($timeStr): int
    {
        if (is_numeric($timeStr)) {
            return (int) $timeStr;
        }

        $total = 0;
        $parts = preg_match_all('/(\d+)([dhms])/', $timeStr, $matches);

        for ($i = 0; $i < $parts; $i++) {
            $value = (int) $matches[1][$i];
            $unit = $matches[2][$i];

            $total += match ($unit) {
                'd' => $value * 86400,
                'h' => $value * 3600,
                'm' => $value * 60,
                's' => $value,
                default => 0,
            };
        }

        return $total;
    }
}
