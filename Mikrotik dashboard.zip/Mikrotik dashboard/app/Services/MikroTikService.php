<?php

namespace App\Services;

use App\Models\Router;
use App\Models\RouterCredential;
use Exception;
use Illuminate\Support\Facades\Log;

/**
 * MikroTik RouterOS API Service
 * 
 * Handles all API communications with MikroTik devices
 * Includes connection pooling, error handling, and queue management
 */
class MikroTikService
{
    protected $client;
    protected $router;
    protected $connected = false;
    protected $timeout = 30;
    protected $retryAttempts = 3;
    protected $retryDelay = 1000; // milliseconds

    public function __construct(Router $router)
    {
        $this->router = $router;
        $this->timeout = (int) config('app.mikrotik_api_timeout', 30);
    }

    /**
     * Connect to MikroTik Router
     */
    public function connect(): bool
    {
        try {
            if ($this->connected) {
                return true;
            }

            $credentials = $this->router->credentials;
            if (!$credentials) {
                throw new Exception('Router credentials not found');
            }

            // Initialize MikroTik API client
            $this->client = new \RouterOS\Client([
                'host' => $this->router->host_ip,
                'port' => $this->router->port,
                'user' => $credentials->username,
                'pass' => $credentials->password,
                'timeout' => $this->timeout,
            ]);

            $this->connected = true;
            
            // Update router status
            $this->router->update([
                'status' => 'online',
                'last_connection_at' => now(),
            ]);

            Log::info("Connected to router: {$this->router->name}");
            return true;

        } catch (Exception $e) {
            Log::error("Failed to connect to router {$this->router->name}: {$e->getMessage()}");
            
            $this->router->update([
                'status' => 'error',
            ]);
            
            return false;
        }
    }

    /**
     * Disconnect from router
     */
    public function disconnect(): void
    {
        if ($this->client && $this->connected) {
            try {
                $this->client->close();
                $this->connected = false;
            } catch (Exception $e) {
                Log::warning("Error disconnecting from router: {$e->getMessage()}");
            }
        }
    }

    /**
     * Check if connected
     */
    public function isConnected(): bool
    {
        return $this->connected;
    }

    /**
     * Execute API query with retry logic
     */
    public function query($path, $args = []): array
    {
        $attempts = 0;

        while ($attempts < $this->retryAttempts) {
            try {
                if (!$this->isConnected()) {
                    if (!$this->connect()) {
                        throw new Exception('Cannot establish connection');
                    }
                }

                $response = $this->client->query($path, $args)->read();
                
                return $response ?? [];

            } catch (Exception $e) {
                $attempts++;
                
                Log::warning(
                    "API query failed (attempt {$attempts}/{$this->retryAttempts}): {$e->getMessage()}"
                );

                if ($attempts < $this->retryAttempts) {
                    usleep($this->retryDelay * 1000);
                    $this->connected = false;
                } else {
                    throw $e;
                }
            }
        }

        return [];
    }

    /**
     * Set new value via API
     */
    public function set($path, $id, $data): bool
    {
        try {
            $this->query($path . '/set', array_merge(['.id' => $id], $data));
            return true;
        } catch (Exception $e) {
            Log::error("Failed to set {$path}: {$e->getMessage()}");
            return false;
        }
    }

    /**
     * Add new item
     */
    public function add($path, $data): string
    {
        try {
            $response = $this->query($path . '/add', $data);
            return $response['.ret'] ?? '';
        } catch (Exception $e) {
            Log::error("Failed to add {$path}: {$e->getMessage()}");
            throw $e;
        }
    }

    /**
     * Remove item
     */
    public function remove($path, $id): bool
    {
        try {
            $this->query($path . '/remove', ['.id' => $id]);
            return true;
        } catch (Exception $e) {
            Log::error("Failed to remove {$path}: {$e->getMessage()}");
            return false;
        }
    }

    /**
     * Disable/Enable item
     */
    public function toggleDisabled($path, $id, $disabled = true): bool
    {
        return $this->set($path, $id, ['disabled' => ($disabled ? 'true' : 'false')]);
    }

    /**
     * Get System Identity and Version
     */
    public function getSystemInfo(): array
    {
        try {
            $identity = $this->query('/system/identity');
            $version = $this->query('/system/package');
            $license = $this->query('/system/license');
            $resources = $this->query('/system/resource');

            return [
                'identity' => $identity[0]['name'] ?? 'Unknown',
                'version' => $version[0]['version'] ?? 'Unknown',
                'license' => $license[0] ?? [],
                'resources' => $resources[0] ?? [],
            ];
        } catch (Exception $e) {
            Log::error("Failed to get system info: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get System Resources (CPU, Memory, Uptime)
     */
    public function getSystemResources(): array
    {
        try {
            $resources = $this->query('/system/resource');
            
            if (empty($resources)) {
                return [];
            }

            $res = $resources[0];

            return [
                'cpu_count' => (int) ($res['cpu-count'] ?? 1),
                'cpu_usage' => (int) ($res['cpu-load'] ?? 0),
                'memory_total' => (int) ($res['total-memory'] ?? 0),
                'memory_free' => (int) ($res['free-memory'] ?? 0),
                'memory_usage' => round(100 - (($res['free-memory'] ?? 0) / ($res['total-memory'] ?? 1) * 100)),
                'uptime' => (int) ($res['uptime'] ?? 0),
                'temperature' => (int) ($res['board-temperature'] ?? null),
            ];
        } catch (Exception $e) {
            Log::error("Failed to get system resources: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get all interfaces with stats
     */
    public function getInterfaces(): array
    {
        try {
            $interfaces = $this->query('/interface');
            
            return array_map(function ($intf) {
                return [
                    '.id' => $intf['.id'] ?? null,
                    'name' => $intf['name'] ?? '',
                    'type' => $intf['type'] ?? 'ether',
                    'disabled' => ($intf['running'] ?? false) ? false : true,
                    'running' => (bool) ($intf['running'] ?? false),
                    'mtu' => (int) ($intf['mtu'] ?? 1500),
                    'mac_address' => $intf['mac-address'] ?? '',
                    'comment' => $intf['comment'] ?? '',
                ];
            }, $interfaces);
        } catch (Exception $e) {
            Log::error("Failed to get interfaces: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get interface statistics and traffic
     */
    public function getInterfaceStats($interfaceName): array
    {
        try {
            $response = $this->query('/interface', [
                'query' => ['name' => $interfaceName],
            ]);

            if (empty($response)) {
                return [];
            }

            $intf = $response[0];

            return [
                'rx_bytes' => (int) ($intf['rx-byte'] ?? 0),
                'tx_bytes' => (int) ($intf['tx-byte'] ?? 0),
                'rx_packets' => (int) ($intf['rx-packet'] ?? 0),
                'tx_packets' => (int) ($intf['tx-packet'] ?? 0),
                'rx_errors' => (int) ($intf['rx-error'] ?? 0),
                'tx_errors' => (int) ($intf['tx-error'] ?? 0),
                'rx_drop' => (int) ($intf['rx-drop'] ?? 0),
                'tx_drop' => (int) ($intf['tx-drop'] ?? 0),
            ];
        } catch (Exception $e) {
            Log::error("Failed to get interface stats for {$interfaceName}: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get IP Addresses
     */
    public function getIpAddresses(): array
    {
        try {
            return $this->query('/ip/address');
        } catch (Exception $e) {
            Log::error("Failed to get IP addresses: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Add IP Address
     */
    public function addIpAddress($interface, $address, $gateway = null): bool
    {
        try {
            $data = [
                'interface' => $interface,
                'address' => $address,
            ];

            if ($gateway) {
                $data['gateway'] = $gateway;
            }

            $this->add('/ip/address', $data);
            return true;
        } catch (Exception $e) {
            Log::error("Failed to add IP address: {$e->getMessage()}");
            return false;
        }
    }

    /**
     * Get DHCP Servers
     */
    public function getDhcpServers(): array
    {
        try {
            return $this->query('/ip/dhcp-server');
        } catch (Exception $e) {
            Log::error("Failed to get DHCP servers: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get DHCP Leases
     */
    public function getDhcpLeases($server = null): array
    {
        try {
            $params = [];
            if ($server) {
                $params['server'] = $server;
            }

            return $this->query('/ip/dhcp-server/lease', $params);
        } catch (Exception $e) {
            Log::error("Failed to get DHCP leases: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get Firewall Filter Rules
     */
    public function getFirewallFilters(): array
    {
        try {
            return $this->query('/ip/firewall/filter');
        } catch (Exception $e) {
            Log::error("Failed to get firewall filters: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get Firewall NAT Rules
     */
    public function getFirewallNats(): array
    {
        try {
            return $this->query('/ip/firewall/nat');
        } catch (Exception $e) {
            Log::error("Failed to get firewall NAT rules: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Add Firewall Filter Rule
     */
    public function addFirewallFilter($data): bool
    {
        try {
            $this->add('/ip/firewall/filter', $data);
            return true;
        } catch (Exception $e) {
            Log::error("Failed to add firewall filter: {$e->getMessage()}");
            return false;
        }
    }

    /**
     * Get Simple Queues
     */
    public function getSimpleQueues(): array
    {
        try {
            return $this->query('/queue/simple');
        } catch (Exception $e) {
            Log::error("Failed to get simple queues: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get PPP Active Connections
     */
    public function getPppActive(): array
    {
        try {
            return $this->query('/ppp/active');
        } catch (Exception $e) {
            Log::error("Failed to get PPP active connections: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get Wireless Interfaces
     */
    public function getWirelessInterfaces(): array
    {
        try {
            return $this->query('/interface/wireless');
        } catch (Exception $e) {
            Log::error("Failed to get wireless interfaces: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Get Wireless Clients (Registration Table)
     */
    public function getWirelessClients($interface = null): array
    {
        try {
            $params = [];
            if ($interface) {
                $params['interface'] = $interface;
            }

            return $this->query('/interface/wireless/registration-table', $params);
        } catch (Exception $e) {
            Log::error("Failed to get wireless clients: {$e->getMessage()}");
            return [];
        }
    }

    /**
     * Enable/Disable Interface
     */
    public function setInterfaceState($interfaceId, $enabled): bool
    {
        return $this->set('/interface', $interfaceId, [
            'disabled' => !$enabled,
        ]);
    }

    /**
     * Execute command
     */
    public function executeCommand($command, $args = []): mixed
    {
        try {
            return $this->query($command, $args);
        } catch (Exception $e) {
            Log::error("Failed to execute command {$command}: {$e->getMessage()}");
            throw $e;
        }
    }

    /**
     * Batch operations
     */
    public function batchUpdate(array $operations): array
    {
        $results = [];

        foreach ($operations as $operation) {
            try {
                $method = $operation['method'] ?? 'query';
                $path = $operation['path'];
                $args = $operation['args'] ?? [];

                $results[] = [
                    'status' => 'success',
                    'path' => $path,
                    'data' => $this->$method($path, $args),
                ];
            } catch (Exception $e) {
                $results[] = [
                    'status' => 'error',
                    'path' => $operation['path'],
                    'error' => $e->getMessage(),
                ];
            }
        }

        return $results;
    }

    /**
     * Destructor - ensure connection is closed
     */
    public function __destruct()
    {
        $this->disconnect();
    }
}
