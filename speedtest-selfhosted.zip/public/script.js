/**
 * SpeedTest Self-Hosted — Frontend Logic
 * Vanilla JavaScript (ES2020+)
 *
 * Architecture:
 *  - SpeedTest       : main test orchestrator
 *  - LatencyTest     : ping & jitter measurement
 *  - DownloadTest    : download speed via fetch stream
 *  - UploadTest      : upload speed via XHR
 *  - ChartManager    : Chart.js realtime graphs
 *  - ISPInfo         : public IP / ISP lookup
 *  - UI              : DOM helpers & animations
 */

'use strict';

/* ═══════════════════════════════════════════════════════════
   CONSTANTS
═══════════════════════════════════════════════════════════ */
const BASE_URL = window.location.origin; // Use same-origin by default

// Download sizes to try progressively (bytes)
const DOWNLOAD_SIZES = [
  5  * 1024 * 1024,  //   5 MB
  10 * 1024 * 1024,  //  10 MB
  25 * 1024 * 1024,  //  25 MB
  50 * 1024 * 1024,  //  50 MB
];

const PING_SAMPLES   = 12;   // number of pings to send
const CHART_HISTORY  = 40;   // data points to show on charts
const CHART_UPDATE_INTERVAL = 200; // ms

/* ═══════════════════════════════════════════════════════════
   TOAST NOTIFICATIONS
═══════════════════════════════════════════════════════════ */
const Toast = (() => {
  const el = document.getElementById('toast');
  let timer;

  /**
   * Show a toast message
   * @param {string} msg - Message to display
   * @param {'info'|'error'|'warn'} type
   * @param {number} duration - ms to show
   */
  function show(msg, type = 'info', duration = 3500) {
    clearTimeout(timer);
    el.textContent = msg;
    el.className = 'toast show' + (type !== 'info' ? ' ' + type : '');
    timer = setTimeout(() => {
      el.classList.remove('show');
    }, duration);
  }

  return { show };
})();

/* ═══════════════════════════════════════════════════════════
   UI HELPERS
═══════════════════════════════════════════════════════════ */
const UI = (() => {
  // Card IDs and value element IDs
  const cards = {
    latency:  { card: 'cardLatency',  val: 'valLatency',  sub: 'subLatency'  },
    jitter:   { card: 'cardJitter',   val: 'valJitter',   sub: 'subJitter'   },
    download: { card: 'cardDownload', val: 'valDownload', sub: 'subDownload' },
    upload:   { card: 'cardUpload',   val: 'valUpload',   sub: 'subUpload'   },
  };

  /**
   * Animate a value change in the card
   */
  function setCardValue(name, value, sub = '') {
    const c = cards[name];
    if (!c) return;
    const valEl = document.getElementById(c.val);
    const subEl = document.getElementById(c.sub);
    if (valEl) {
      valEl.textContent = value;
      valEl.classList.remove('value-animate');
      void valEl.offsetWidth; // reflow to restart animation
      valEl.classList.add('value-animate');
    }
    if (subEl) subEl.textContent = sub;
  }

  /**
   * Set a card as active (currently testing)
   */
  function setCardActive(name) {
    Object.keys(cards).forEach(k => {
      const el = document.getElementById(cards[k].card);
      if (el) el.classList.remove('active', 'done');
    });
    const c = cards[name];
    if (c) {
      const el = document.getElementById(c.card);
      if (el) el.classList.add('active');
    }
  }

  /**
   * Mark a card as done
   */
  function setCardDone(name) {
    const c = cards[name];
    if (c) {
      const el = document.getElementById(c.card);
      if (el) { el.classList.remove('active'); el.classList.add('done'); }
    }
  }

  /**
   * Update progress bar (0-100)
   */
  function setProgress(pct, label) {
    const bar   = document.getElementById('progressBar');
    const lbl   = document.getElementById('progressLabel');
    const wrap  = document.getElementById('progressWrap');
    if (bar)  bar.style.setProperty('--progress', pct + '%');
    if (lbl)  lbl.textContent = label;
    if (wrap) wrap.classList.toggle('visible', pct >= 0);
  }

  /**
   * Toggle testing state on start button
   */
  function setTesting(isTesting) {
    const btn = document.getElementById('startBtn');
    const txt = btn.querySelector('.btn-start__text');
    if (isTesting) {
      btn.classList.add('testing');
      btn.disabled = true;
      if (txt) txt.textContent = 'Testing…';
    } else {
      btn.classList.remove('testing');
      btn.disabled = false;
      if (txt) txt.textContent = 'Start Test';
    }
  }

  /**
   * Show or hide the charts section
   */
  function showCharts(visible) {
    const sec = document.getElementById('chartsSection');
    if (sec) sec.classList.toggle('visible', visible);
  }

  return { setCardValue, setCardActive, setCardDone, setProgress, setTesting, showCharts };
})();

/* ═══════════════════════════════════════════════════════════
   CHART MANAGER
═══════════════════════════════════════════════════════════ */
const ChartManager = (() => {
  let chartDown, chartUp, chartPing;
  let intervalId = null;

  // Current pending values
  let pendingDown = null, pendingUp = null, pendingPing = null;

  /**
   * Create an empty time-series dataset
   */
  function makeData(color, fill = false) {
    return {
      labels: Array(CHART_HISTORY).fill(''),
      datasets: [{
        data: Array(CHART_HISTORY).fill(null),
        borderColor: color,
        backgroundColor: fill ? color + '22' : 'transparent',
        borderWidth: 2,
        pointRadius: 0,
        tension: 0.4,
        fill: fill,
      }]
    };
  }

  /**
   * Common Chart.js options
   */
  function makeOptions(maxY = null) {
    return {
      responsive: true,
      maintainAspectRatio: false,
      animation: { duration: 180 },
      plugins: { legend: { display: false }, tooltip: { enabled: false } },
      scales: {
        x: { display: false },
        y: {
          display: true,
          min: 0,
          max: maxY || undefined,
          grid: { color: '#e8edf5', drawBorder: false },
          ticks: { color: '#6b7a99', font: { size: 10 }, maxTicksLimit: 4 },
        },
      },
    };
  }

  /**
   * Push a value into a chart (shifts old values)
   */
  function pushValue(chart, value) {
    if (!chart) return;
    const data = chart.data.datasets[0].data;
    data.push(value);
    data.shift();
    chart.update('none'); // no animation for live updates
  }

  /**
   * Initialize all charts
   */
  function init() {
    const ctxDown = document.getElementById('chartDownload');
    const ctxUp   = document.getElementById('chartUpload');
    const ctxPing = document.getElementById('chartPing');

    chartDown = new Chart(ctxDown, {
      type: 'line',
      data: makeData('#0ea5e9', true),
      options: makeOptions(),
    });

    chartUp = new Chart(ctxUp, {
      type: 'line',
      data: makeData('#10b981', true),
      options: makeOptions(),
    });

    chartPing = new Chart(ctxPing, {
      type: 'line',
      data: makeData('#f59e0b', false),
      options: makeOptions(),
    });
  }

  /**
   * Start the 200ms update loop
   */
  function startLoop() {
    stopLoop();
    intervalId = setInterval(() => {
      if (pendingDown !== null) { pushValue(chartDown, pendingDown); pendingDown = null; }
      if (pendingUp   !== null) { pushValue(chartUp,   pendingUp);   pendingUp   = null; }
      if (pendingPing !== null) { pushValue(chartPing, pendingPing); pendingPing = null; }
    }, CHART_UPDATE_INTERVAL);
  }

  function stopLoop() {
    if (intervalId) { clearInterval(intervalId); intervalId = null; }
  }

  return {
    init,
    startLoop,
    stopLoop,
    addDownload: (v) => { pendingDown = v; },
    addUpload:   (v) => { pendingUp   = v; },
    addPing:     (v) => { pendingPing = v; },
  };
})();

/* ═══════════════════════════════════════════════════════════
   LATENCY TEST (Ping & Jitter)
═══════════════════════════════════════════════════════════ */
const LatencyTest = {
  /**
   * Measure ping N times, return { avg, min, max, jitter }
   * @param {string} baseUrl
   * @param {AbortSignal} signal
   */
  async measure(baseUrl, signal) {
    const pings = [];
    UI.setCardActive('latency');

    for (let i = 0; i < PING_SAMPLES; i++) {
      if (signal.aborted) break;
      try {
        const t0 = performance.now();
        await fetch(`${baseUrl}/ping?t=${Date.now()}`, {
          method: 'GET',
          cache: 'no-store',
          signal,
        });
        const rtt = performance.now() - t0;
        pings.push(rtt);

        // Realtime update
        const avg = pings.reduce((a, b) => a + b, 0) / pings.length;
        UI.setCardValue('latency', avg.toFixed(1), `${i + 1}/${PING_SAMPLES} samples`);
        ChartManager.addPing(avg);

        // Small delay between pings
        await sleep(80);
      } catch (e) {
        if (e.name !== 'AbortError') {
          console.warn('Ping failed:', e.message);
        }
      }
    }

    if (pings.length === 0) throw new Error('All pings failed');

    const avg    = pings.reduce((a, b) => a + b, 0) / pings.length;
    const min    = Math.min(...pings);
    const max    = Math.max(...pings);
    const jitter = pings.length > 1
      ? pings.slice(1).reduce((sum, v, i) => sum + Math.abs(v - pings[i]), 0) / (pings.length - 1)
      : 0;

    UI.setCardValue('latency', avg.toFixed(1), `min ${min.toFixed(0)} · max ${max.toFixed(0)} ms`);
    UI.setCardValue('jitter',  jitter.toFixed(1), `${pings.length} samples`);
    UI.setCardDone('latency');
    UI.setCardDone('jitter');

    return { avg, min, max, jitter };
  }
};

/* ═══════════════════════════════════════════════════════════
   DOWNLOAD TEST
═══════════════════════════════════════════════════════════ */
const DownloadTest = {
  /**
   * Download escalating sizes, report realtime Mbps
   * @param {string} baseUrl
   * @param {AbortSignal} signal
   */
  async measure(baseUrl, signal) {
    UI.setCardActive('download');
    let bestMbps = 0;
    let totalBytes = 0, totalMs = 0;

    for (const size of DOWNLOAD_SIZES) {
      if (signal.aborted) break;

      try {
        const url = `${baseUrl}/download?size=${size}&t=${Date.now()}`;
        const t0 = performance.now();

        const response = await fetch(url, { cache: 'no-store', signal });
        if (!response.ok) throw new Error(`HTTP ${response.status}`);

        const reader = response.body.getReader();
        let received = 0;
        let lastUpdate = performance.now();

        // Stream & measure chunk-by-chunk
        while (true) {
          if (signal.aborted) { reader.cancel(); break; }
          const { done, value } = await reader.read();
          if (done) break;

          received += value.byteLength;
          const now = performance.now();
          const elapsed = now - t0;

          // Update UI every ~150ms for smooth animation
          if (now - lastUpdate > 150) {
            const mbps = (received * 8) / (elapsed / 1000) / 1_000_000;
            bestMbps = Math.max(bestMbps, mbps);
            UI.setCardValue('download', mbps.toFixed(1), formatBytes(received));
            ChartManager.addDownload(mbps);
            lastUpdate = now;
          }
        }

        const elapsed = performance.now() - t0;
        const mbps = (received * 8) / (elapsed / 1000) / 1_000_000;
        totalBytes += received;
        totalMs    += elapsed;
        bestMbps    = Math.max(bestMbps, mbps);

        UI.setCardValue('download', mbps.toFixed(1), `${formatBytes(received)} · ${(elapsed/1000).toFixed(1)}s`);
        ChartManager.addDownload(mbps);

        // If speed is very high, skip larger files (no need to run all)
        if (mbps > 800 && size >= 25 * 1024 * 1024) break;

      } catch (e) {
        if (e.name !== 'AbortError') {
          console.warn('Download chunk failed:', e.message);
          break;
        }
      }
    }

    const finalMbps = totalMs > 0
      ? (totalBytes * 8) / (totalMs / 1000) / 1_000_000
      : bestMbps;

    UI.setCardValue('download', finalMbps.toFixed(1), formatBytes(totalBytes) + ' transferred');
    UI.setCardDone('download');
    return finalMbps;
  }
};

/* ═══════════════════════════════════════════════════════════
   UPLOAD TEST
═══════════════════════════════════════════════════════════ */
const UploadTest = {
  /**
   * Generate random data and POST it in parallel streams
   * @param {string} baseUrl
   * @param {AbortSignal} signal
   */
  async measure(baseUrl, signal) {
    UI.setCardActive('upload');

    const UPLOAD_SIZE = 20 * 1024 * 1024; // 20 MB per stream
    const STREAMS     = 3;                  // parallel streams
    const url = `${baseUrl}/upload?t=${Date.now()}`;

    let totalSent = 0;
    const t0 = performance.now();
    let lastUpdate = performance.now();

    // Generate random buffer (pseudo-random, prevents compression)
    function makeBuffer(size) {
      const buf = new Uint8Array(size);
      for (let i = 0; i < size; i += 4) {
        const r = Math.random() * 0xFFFFFFFF >>> 0;
        buf[i]     = (r)       & 0xFF;
        buf[i + 1] = (r >> 8)  & 0xFF;
        buf[i + 2] = (r >> 16) & 0xFF;
        buf[i + 3] = (r >> 24) & 0xFF;
      }
      return buf;
    }

    // Single upload stream using XMLHttpRequest for progress events
    function uploadStream(data) {
      return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', url, true);
        xhr.setRequestHeader('Content-Type', 'application/octet-stream');
        xhr.timeout = 60000;

        xhr.upload.onprogress = (e) => {
          if (e.lengthComputable) {
            totalSent += e.loaded - (xhr._prevLoaded || 0);
            xhr._prevLoaded = e.loaded;

            const now = performance.now();
            if (now - lastUpdate > 150) {
              const elapsed = now - t0;
              const mbps = (totalSent * 8) / (elapsed / 1000) / 1_000_000;
              UI.setCardValue('upload', mbps.toFixed(1), formatBytes(totalSent));
              ChartManager.addUpload(mbps);
              lastUpdate = now;
            }
          }
        };

        xhr.onload = () => resolve(xhr.responseText);
        xhr.onerror = () => reject(new Error('Upload network error'));
        xhr.ontimeout = () => reject(new Error('Upload timeout'));

        // Hook abort signal
        if (signal) {
          signal.addEventListener('abort', () => xhr.abort(), { once: true });
        }

        const blob = new Blob([data], { type: 'application/octet-stream' });
        xhr.send(blob);
      });
    }

    try {
      // Launch parallel streams
      const streams = Array.from({ length: STREAMS }, () =>
        uploadStream(makeBuffer(UPLOAD_SIZE))
      );
      await Promise.all(streams);
    } catch (e) {
      if (e.name !== 'AbortError' && !signal.aborted) {
        console.warn('Upload error:', e.message);
      }
    }

    const elapsed = performance.now() - t0;
    const finalMbps = (totalSent * 8) / (elapsed / 1000) / 1_000_000;

    UI.setCardValue('upload', finalMbps.toFixed(1), formatBytes(totalSent) + ' sent');
    UI.setCardDone('upload');
    return finalMbps;
  }
};

/* ═══════════════════════════════════════════════════════════
   ISP INFO
═══════════════════════════════════════════════════════════ */
const ISPInfo = {
  async load() {
    try {
      // Use ipapi.co (free tier, no key required)
      const res  = await fetch('https://ipapi.co/json/', { cache: 'no-store' });
      if (!res.ok) throw new Error('ISP API failed');
      const data = await res.json();

      setEl('ispIp',       data.ip         || '—');
      setEl('ispName',     data.org?.replace(/^AS\d+\s+/, '') || '—');
      setEl('ispAsn',      data.asn         || '—');
      setEl('ispLocation', [data.city, data.country_name].filter(Boolean).join(', ') || '—');
    } catch (e) {
      // Fallback: try our own /ip endpoint
      try {
        const res  = await fetch('/ip');
        const data = await res.json();
        setEl('ispIp', data.ip || '—');
      } catch (_) {
        console.warn('Could not fetch ISP info');
      }
    }
  }
};

/* ═══════════════════════════════════════════════════════════
   SERVER MANAGEMENT
═══════════════════════════════════════════════════════════ */
const Servers = {
  list: [],

  /**
   * Load servers from /servers and populate the dropdown
   */
  async load() {
    try {
      const res  = await fetch('/servers');
      const data = await res.json();
      this.list = data;

      const sel = document.getElementById('serverSelect');
      if (!sel) return;

      sel.innerHTML = '';
      data.forEach((s, i) => {
        const opt = document.createElement('option');
        opt.value   = s.url;
        opt.textContent = s.name;
        if (i === 0) opt.selected = true;
        sel.appendChild(opt);
      });
    } catch (e) {
      console.warn('Could not load servers:', e.message);
    }
  },

  /**
   * Auto-select: ping all servers and pick lowest latency
   * @param {AbortSignal} signal
   * @returns {string} best server URL
   */
  async selectBest(signal) {
    const realServers = this.list.filter(s => s.url !== 'auto');
    if (realServers.length === 0) return BASE_URL;

    UI.setProgress(2, 'Finding best server…');

    const results = await Promise.allSettled(
      realServers.map(async (s) => {
        try {
          const t0 = performance.now();
          await fetch(`${s.url}/ping?t=${Date.now()}`, { cache: 'no-store', signal });
          return { url: s.url, rtt: performance.now() - t0 };
        } catch {
          return { url: s.url, rtt: Infinity };
        }
      })
    );

    let best = BASE_URL;
    let bestRtt = Infinity;

    results.forEach(r => {
      if (r.status === 'fulfilled' && r.value.rtt < bestRtt) {
        bestRtt = r.value.rtt;
        best    = r.value.url;
      }
    });

    return best;
  },

  getSelected() {
    const sel = document.getElementById('serverSelect');
    return sel ? sel.value : 'auto';
  }
};

/* ═══════════════════════════════════════════════════════════
   MAIN SPEED TEST ORCHESTRATOR
═══════════════════════════════════════════════════════════ */
const SpeedTest = {
  controller: null,

  async run() {
    if (this.controller) {
      // Already running — abort
      this.controller.abort();
      return;
    }

    this.controller = new AbortController();
    const signal = this.controller.signal;

    // Reset UI
    UI.setTesting(true);
    UI.setProgress(0, 'Initializing…');
    UI.showCharts(true);
    ChartManager.startLoop();

    // Reset card values
    ['latency','jitter','download','upload'].forEach(k => {
      UI.setCardValue(k, '—');
    });

    try {
      // ── 1. Resolve server ─────────────────────────────────
      let serverUrl = Servers.getSelected();
      if (serverUrl === 'auto') {
        serverUrl = await Servers.selectBest(signal);
      }
      console.info('Using server:', serverUrl);

      // ── 2. Ping & Jitter ──────────────────────────────────
      UI.setProgress(5, 'Measuring latency…');
      const latency = await LatencyTest.measure(serverUrl, signal);
      ChartManager.addPing(latency.avg);

      // ── 3. Download ───────────────────────────────────────
      UI.setProgress(35, 'Testing download…');
      const dlMbps = await DownloadTest.measure(serverUrl, signal);

      // ── 4. Upload ─────────────────────────────────────────
      UI.setProgress(75, 'Testing upload…');
      const ulMbps = await UploadTest.measure(serverUrl, signal);

      // ── 5. Done ───────────────────────────────────────────
      UI.setProgress(100, `Done · ${new Date().toLocaleTimeString()}`);
      Toast.show('Test complete!', 'info', 2500);

    } catch (e) {
      if (e.name === 'AbortError') {
        UI.setProgress(-1, '');
        return;
      }

      console.error('SpeedTest error:', e);

      if (!navigator.onLine) {
        Toast.show('No Internet Connection', 'error');
      } else if (e.message.includes('timeout') || e.message.includes('Timeout')) {
        Toast.show('Server Timeout', 'error');
      } else {
        Toast.show('Connection Failed', 'error');
      }

      UI.setProgress(-1, '');
    } finally {
      ChartManager.stopLoop();
      UI.setTesting(false);
      this.controller = null;
    }
  }
};

/* ═══════════════════════════════════════════════════════════
   UTILITIES
═══════════════════════════════════════════════════════════ */

/** Pause execution for `ms` milliseconds */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/** Format bytes as human-readable string */
function formatBytes(bytes) {
  if (bytes < 1024)       return `${bytes} B`;
  if (bytes < 1024 ** 2)  return `${(bytes / 1024).toFixed(1)} KB`;
  if (bytes < 1024 ** 3)  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
  return `${(bytes / 1024 ** 3).toFixed(2)} GB`;
}

/** Set text content of an element by ID */
function setEl(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

/* ═══════════════════════════════════════════════════════════
   ONLINE / OFFLINE EVENTS
═══════════════════════════════════════════════════════════ */
window.addEventListener('offline', () => {
  Toast.show('No Internet Connection', 'error', 5000);
});

window.addEventListener('online', () => {
  Toast.show('Connection restored', 'info', 2000);
});

/* ═══════════════════════════════════════════════════════════
   NAVBAR TOGGLE (Mobile)
═══════════════════════════════════════════════════════════ */
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('menuToggle');
  const links  = document.getElementById('navLinks');

  if (toggle && links) {
    toggle.addEventListener('click', () => {
      const open = links.classList.toggle('open');
      toggle.classList.toggle('open', open);
      toggle.setAttribute('aria-expanded', String(open));
    });

    // Close menu when a link is clicked
    links.querySelectorAll('.nav-link').forEach(a => {
      a.addEventListener('click', () => {
        links.classList.remove('open');
        toggle.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // Active link on scroll
  const sections = ['home', 'servers-section', 'about'];
  const navLinks = document.querySelectorAll('.nav-link');

  function updateActiveLink() {
    const scrollY = window.scrollY + 80;
    sections.forEach((id, i) => {
      const el = document.getElementById(id);
      if (!el) return;
      const top = el.offsetTop;
      const bot = top + el.offsetHeight;
      if (scrollY >= top && scrollY < bot) {
        navLinks.forEach(l => l.classList.remove('active'));
        if (navLinks[i]) navLinks[i].classList.add('active');
      }
    });
  }

  window.addEventListener('scroll', updateActiveLink, { passive: true });
});

/* ═══════════════════════════════════════════════════════════
   INIT
═══════════════════════════════════════════════════════════ */
async function init() {
  // Initialize charts
  ChartManager.init();

  // Load servers into dropdown
  await Servers.load();

  // Load ISP info
  ISPInfo.load();

  // Wire up start button
  const startBtn = document.getElementById('startBtn');
  if (startBtn) {
    startBtn.addEventListener('click', () => SpeedTest.run());
  }
}

// Boot when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', init);
} else {
  init();
}
