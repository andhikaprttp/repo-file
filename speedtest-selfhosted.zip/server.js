/**
 * SpeedTest Self-Hosted - Backend Server
 * Node.js + Express
 * Endpoints: /ping, /download, /upload, /servers, /ip
 */

const express = require('express');
const compression = require('compression');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(compression()); // Gzip compression
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.raw({ type: '*/*', limit: '200mb' })); // For upload endpoint

// Disable caching for speed test endpoints
app.use('/ping', (req, res, next) => {
  res.set('Cache-Control', 'no-store, no-cache, must-revalidate');
  res.set('Pragma', 'no-cache');
  next();
});

// ─── Routes ──────────────────────────────────────────────────────────────────

/**
 * GET /ping
 * Returns small JSON for latency measurement
 */
app.get('/ping', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({ status: 'ok', time: Date.now() });
});

/**
 * GET /download
 * Streams random bytes to client for download speed measurement
 * Query params: size (in bytes, default 10MB)
 */
app.get('/download', (req, res) => {
  const size = Math.min(
    parseInt(req.query.size) || 10 * 1024 * 1024,
    200 * 1024 * 1024 // max 200MB
  );

  res.set({
    'Content-Type': 'application/octet-stream',
    'Content-Length': size,
    'Cache-Control': 'no-store',
    'Content-Disposition': 'attachment; filename="speedtest.bin"',
  });

  // Stream random data in chunks for memory efficiency
  const CHUNK = 64 * 1024; // 64KB chunks
  let sent = 0;

  const sendChunk = () => {
    while (sent < size) {
      const remaining = size - sent;
      const chunkSize = Math.min(CHUNK, remaining);
      const buf = Buffer.alloc(chunkSize);
      // Fill with pseudo-random to prevent compression cheating
      for (let i = 0; i < chunkSize; i += 4) {
        buf.writeUInt32LE(Math.random() * 0xFFFFFFFF >>> 0, i);
      }
      const ok = res.write(buf);
      sent += chunkSize;
      if (!ok) {
        // Backpressure - wait for drain
        res.once('drain', sendChunk);
        return;
      }
    }
    res.end();
  };

  req.on('close', () => {
    // Client aborted, stop sending
    sent = size;
  });

  sendChunk();
});

/**
 * POST /upload
 * Receives data from client for upload speed measurement
 * Discards data immediately (no storage)
 */
app.post('/upload', (req, res) => {
  let received = 0;

  req.on('data', (chunk) => {
    received += chunk.length;
    // Discard data immediately - we only care about speed
  });

  req.on('end', () => {
    res.set('Cache-Control', 'no-store');
    res.json({ status: 'ok', received });
  });

  req.on('error', () => {
    res.status(500).json({ status: 'error' });
  });
});

/**
 * GET /servers
 * Returns list of available speed test servers from config
 */
app.get('/servers', (req, res) => {
  try {
    const serversPath = path.join(__dirname, 'config', 'servers.json');
    const servers = JSON.parse(fs.readFileSync(serversPath, 'utf8'));
    res.json(servers);
  } catch (err) {
    res.status(500).json({ error: 'Could not load servers' });
  }
});

/**
 * GET /ip
 * Returns client IP info using ipapi.co as external lookup
 */
app.get('/ip', async (req, res) => {
  // Get real client IP (behind proxy)
  const ip =
    req.headers['x-forwarded-for']?.split(',')[0].trim() ||
    req.headers['x-real-ip'] ||
    req.socket.remoteAddress;

  // Return IP so the client can use a public API for ISP info
  res.json({ ip });
});

// ─── Serve index.html for all other routes ───────────────────────────────────
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ─── Start ───────────────────────────────────────────────────────────────────
app.listen(PORT, () => {
  console.log(`SpeedTest server running at http://localhost:${PORT}`);
});

module.exports = app;
