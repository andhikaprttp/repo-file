# SpeedTest Self-Hosted

Internet speed test yang mengukur koneksi **Browser ↔ Server** secara langsung.  
Download, upload, latency, dan jitter semuanya diukur dari browser pengguna — bukan antar-VPS.

---

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Start server
npm start
# Server berjalan di http://localhost:3000
```

---

## Struktur Folder

```
project/
├── server.js          # Express backend
├── package.json
├── config/
│   └── servers.json   # Daftar server (tambah di sini)
└── public/
    ├── index.html     # Frontend HTML
    ├── style.css      # Stylesheet
    └── script.js      # Frontend logic
```

---

## Menambah Server

Edit `config/servers.json`:

```json
[
  { "name": "Auto",      "url": "auto" },
  { "name": "Jakarta",   "url": "https://jakarta.domain.com" },
  { "name": "Singapore", "url": "https://sg.domain.com" }
]
```

Server dengan `"url": "auto"` akan otomatis memilih server dengan latency terendah.

---

## Endpoints Backend

| Method | Path        | Deskripsi                          |
|--------|-------------|-------------------------------------|
| GET    | /ping       | Pengukuran latency (respons kecil)  |
| GET    | /download   | Stream data random untuk download   |
| POST   | /upload     | Menerima & membuang data upload     |
| GET    | /servers    | Daftar server dari servers.json     |
| GET    | /ip         | IP address client                   |

Query params `/download`:
- `size` — ukuran byte yang distream (default: 10MB, max: 200MB)

---

## Deploy ke VPS (Production)

```bash
# Gunakan PM2 untuk process management
npm install -g pm2
pm2 start server.js --name speedtest
pm2 save

# Nginx reverse proxy (contoh)
# proxy_pass http://localhost:3000;
```

### Nginx config (HTTPS)
```nginx
server {
    listen 443 ssl;
    server_name yourdomain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        # Penting untuk streaming download yang besar
        proxy_buffering off;
        proxy_read_timeout 120s;
    }
}
```

---

## Multi-Server Setup

Untuk mendukung multi-server, deploy `server.js` ke beberapa VPS  
dan daftarkan URL-nya di `servers.json` pada server utama.

Setiap VPS hanya memerlukan `server.js` yang sama (tidak perlu `public/`  
jika hanya digunakan sebagai backend server).

---

## Lisensi

MIT
